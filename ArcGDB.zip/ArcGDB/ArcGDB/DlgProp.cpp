// DlgProp.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgProp.h"
#include "xml.h"

//#import "msxml3.dll" named_guids
//#import "C:\Program Files (x86)\Common Files\SuperGeo\SGGML.dll" named_guids
//
//namespace SGGML
//{
//	typedef MSXML2::IXMLDOMElement IXMLArchiveElement;
//	typedef MSXML2::IXMLDOMElementPtr IXMLArchiveElementPtr;
//	typedef MSXML2::IXMLDOMNodeList IXMLArchiveElementList;
//	typedef MSXML2::IXMLDOMNodeListPtr IXMLArchiveElementListPtr;
//	typedef MSXML2::IXMLDOMDocument IXMLArchive;
//	typedef MSXML2::IXMLDOMDocumentPtr IXMLArchivePtr;
//}

// CDlgProp ��ܤ��

IMPLEMENT_DYNAMIC(CDlgProp, CDialog)

CDlgProp::CDlgProp(SGCore::IDBWorkspacePtr pWS, SGCore::INameCollectionPtr pNames, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PROP, pParent)
{
	m_pWS = pWS;
	m_pNames = pNames;
}

CDlgProp::~CDlgProp()
{
}

void CDlgProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST2, m_list2);
	DDX_Control(pDX, IDC_LIST3, m_list3);
	DDX_Control(pDX, IDC_LIST4, m_list4);
}


BEGIN_MESSAGE_MAP(CDlgProp, CDialog)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST2, &CDlgProp::OnLvnItemchangedList2)
END_MESSAGE_MAP()


// CDlgProp �T���B�z�`��
BOOL CDlgProp::OnInitDialog()
{
	CDialog::OnInitDialog();

	DWORD dwStyle = m_list2.GetExtendedStyle();
	dwStyle |= LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT;
	m_list2.SetExtendedStyle(dwStyle);
	dwStyle = m_list3.GetExtendedStyle();
	dwStyle |= LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT;
	m_list3.SetExtendedStyle(dwStyle); 
	dwStyle = m_list4.GetExtendedStyle();
	dwStyle |= LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT;
	m_list4.SetExtendedStyle(dwStyle);

	RECT rc;
	m_list2.GetClientRect(&rc);
	int w = ((rc.right - rc.left)+2)/3-10;

	SGGML::IXMLArchivePtr pDoc;
	pDoc.CreateInstance(MSXML2::CLSID_DOMDocument);
	if (pDoc)
		pDoc->put_async(FALSE);

	SGFileGDB::IGDBWorkspacePtr pWS = m_pWS;
	long cnt;
	m_pNames->get_NameCount(&cnt);

	m_defs.SetSize(cnt);
	m_list2.InsertColumn(0, L"Domain Name", LVCFMT_LEFT, w, 0);
	m_list2.InsertColumn(1, L"Description", LVCFMT_LEFT, w+w, 0);
	m_list3.InsertColumn(0, L"Name", LVCFMT_LEFT, w, 0);
	m_list3.InsertColumn(1, L"Description", LVCFMT_LEFT, w+w, 0);

	m_list4.InsertColumn(0, L"Code", LVCFMT_LEFT, w, 0);
	m_list4.InsertColumn(1, L"Description", LVCFMT_LEFT, w+w, 0);

	m_list2.SetRedraw(FALSE);
	for (int i = 0; i < cnt; i++)
	{
		_bstr_t name = m_pNames->GetName(i);
		_bstr_t def = pWS->GetDomainDefinition(name);
		m_defs.SetAt(i, def);
		CString tbuf = name;
		int nRow=m_list2.InsertItem(i, tbuf);
		tbuf.Empty();
		VARIANT_BOOL b;
		if (pDoc->raw_loadXML(def, &b) == S_OK && b)
		{
			SGGML::IXMLArchiveElementPtr pElem;
			pDoc->get_documentElement(&pElem);
			if (pElem)
			{
				tbuf=GetNodeText(FindSingleNode(pElem, L"Description"));
			}
		}
		m_list2.SetItemText(nRow, 1, tbuf);
	}
	if (cnt > 0)
	{
		m_list2.SetItemState(0, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		//ListItems(0);
	}
	m_list2.SetRedraw();


	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}

//http://help.arcgis.com/en/arcgisdesktop/10.0/help/index.html#//001s00000001000000.htm
//https://trac.osgeo.org/gdal/ticket/5741
void CDlgProp::ListItems(int seli)
{
	m_list3.SetRedraw(FALSE);
	m_list4.SetRedraw(FALSE);
	m_list3.DeleteAllItems();
	m_list4.DeleteAllItems();
	int nRow;
	CString buf;
	SGGML::IXMLArchivePtr pDoc;
	pDoc.CreateInstance(MSXML2::CLSID_DOMDocument);
	if (pDoc)
		pDoc->put_async(FALSE);
	
	BSTR def=m_defs[seli].AllocSysString();
	VARIANT_BOOL b;
	if (pDoc->raw_loadXML(def, &b) == S_OK && b)
	{
		SGGML::IXMLArchiveElementPtr pRoot;
		SGGML::IXMLArchiveElementPtr pElem;
		pDoc->get_documentElement(&pRoot);
		if (pRoot)
		{
			//http://help.arcgis.com/en/arcgisdesktop/10.0/help/index.html#/Create_Domain/00170000001z000000/
			//esri:CodedValueDomain,esri:RangeDomain
			nRow = m_list3.InsertItem(m_list3.GetItemCount(), L"DomainType");
			buf = GetNodeAttribute(pRoot, L"type");
			if (buf.IsEmpty())
				buf = GetNodeAttribute(pRoot, L"xsi:type");

			buf.Replace(L"esri:", L"");
			m_list3.SetItemText(nRow, 1, buf);

			buf = GetNodeText(FindSingleNode(pRoot, L"FieldType"));
			if (!buf.IsEmpty())
			{
				nRow = m_list3.InsertItem(m_list3.GetItemCount(), L"FieldType");
				buf.Replace(L"esriFieldType", L"");
				m_list3.SetItemText(nRow, 1,  buf);
			}
			buf = GetNodeText(FindSingleNode(pRoot, L"MergePolicy"));
			if (!buf.IsEmpty())
			{
				nRow = m_list3.InsertItem(m_list3.GetItemCount(), L"MergePolicy");
				buf.Replace(L"esriMPT", L"");
				m_list3.SetItemText(nRow, 1, buf);
			}
			buf = GetNodeText(FindSingleNode(pRoot, L"SplitPolicy"));
			if (!buf.IsEmpty())
			{
				nRow = m_list3.InsertItem(m_list3.GetItemCount(), L"SplitPolicy");
				buf.Replace(L"esriSPT", L"");
				m_list3.SetItemText(nRow, 1, buf);
			}
			//nRow = m_list3.InsertItem(m_list3.GetItemCount(), L"Owner");
			//m_list3.SetItemText(nRow, 1, GetNodeText(FindSingleNode(pRoot, L"Owner")));
			CString valbuf;
			SGGML::IXMLArchiveElementListPtr pNodes = GetChilds(pRoot);
			for (int k = 0; k < pNodes->length; k++)
			{
				pElem = pNodes->Getitem(k);
				buf=GetNodeTag(pElem);
				if (buf.IsEmpty() || (buf.CompareNoCase(L"DomainName") == 0 || buf.CompareNoCase(L"Description") == 0 || buf.CompareNoCase(L"CodedValues") == 0 ||
					buf.CompareNoCase(L"FieldType") == 0 || buf.CompareNoCase(L"MergePolicy") == 0 || buf.CompareNoCase(L"SplitPolicy") == 0))
					continue;
				valbuf = GetNodeText(pElem);
				if (!valbuf.IsEmpty())
				{
					nRow = m_list3.InsertItem(m_list3.GetItemCount(), buf);
					m_list3.SetItemText(nRow, 1, valbuf);
				}
			}
			SGGML::IXMLArchiveElementPtr pCodes=FindSingleNode(pRoot, L"CodedValues");
			if (pCodes)
			{
				SGGML::IXMLArchiveElementListPtr pList=FindNodeList(pCodes, L"CodedValue");
				TRACE("codevalue n=%d\n",pList->length);
				for (int k = 0; k < pList->length; k++)
				{
					pElem = pList->Getitem(k);
					buf=GetNodeText(FindSingleNode(pElem, L"Code"));
					if (!buf.IsEmpty())
					{
						nRow = m_list4.InsertItem(m_list4.GetItemCount(), buf);
						buf = GetNodeText(FindSingleNode(pElem, L"Name"));
						//if (buf.IsEmpty())
						//	buf = GetNodeText(FindSingleNode(pElem, L"Description"));
						m_list4.SetItemText(nRow, 1, buf);
					}
				}
			}
		}
	}
	::SysFreeString(def);
	m_list3.SetRedraw();
	m_list4.SetRedraw();
}

void CDlgProp::OnLvnItemchangedList2(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	if ((pNMLV->uOldState & LVIS_SELECTED) == 0 && (pNMLV->uNewState & LVIS_SELECTED) == LVIS_SELECTED)
	{
		TRACE("%d sel\n", pNMLV->iItem);
		ListItems(pNMLV->iItem);
	}
	*pResult = 0;
}
