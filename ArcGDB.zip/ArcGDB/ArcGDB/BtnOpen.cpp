// BtnOpen.cpp : CBtnOpen ����@

#include "stdafx.h"
#include "BtnOpen.h"
#include "DirDialog.h"
#include "SGUtils.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CBtnOpen

STDMETHODIMP CBtnOpen::raw_InitItem(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	m_pApp = Parent;
	g_gdbList.Clear();
	return S_OK;
}

STDMETHODIMP CBtnOpen::raw_ExitItem(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	g_gdbList.Clear();
	m_pApp = NULL;
	return S_OK;
}




STDMETHODIMP CBtnOpen::raw_OnCommand(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CDirDialog dd;
#ifdef _DEBUG
	if (m_curPath.IsEmpty())
		m_curPath = L"f:\\test\\gdb";
#endif
	dd.m_strSelDir = m_curPath;
	if (!dd.DoBrowse(AfxGetMainWnd()))
		return S_OK;

	m_curPath = dd.m_strPath;
	SGFileGDB::IGDBWorkspacePtr pGWS = g_gdbList.GetGDB(m_curPath, TRUE);
	if (pGWS==NULL)
	{
		AfxMessageBox(_T("Not a valid FileGDB Folder!"));
		return S_OK;
	}


	return S_OK;

	SGCore::IDBWorkspacePtr pWS = pGWS;
	SGCore::INameCollectionPtr pTables = pWS->TableNames(_T(""));

	CArray<LAYInfo> tbs;
	CArray<LAYInfo> infos; //not path
	CArray<LAYInfo> infos2;
	LAYInfo li;
	long cnt;
	pTables->get_NameCount(&cnt);
	for (int i = 0; i < cnt; i++)
	{
		CString dd = (LPCTSTR)pTables->GetName(i);
		_tcscpy_s(li.name, 256, dd);
		SGCore::SGOGeometryType type = SGCore::SGO_GT_Unknown; // pWS->FieldGeometryType(name, _T(""));
		SGCore::IFeatureClassPtr pFC = pWS->OpenTable(_bstr_t(li.name), "", type);
		if (pFC)
		{
			li.pUnk = pFC;
			li.type = (int)pFC->GetFeatureType();
			if (li.type == SGCore::SGO_GT_Unknown)
				tbs.Add(li);
			else
			{
				int ti = dd.Find(L'\\');
				if (ti<0)
					ti = dd.Find(L'/');
				if (ti > 0)
					infos2.Add(li);
				else
					infos.Add(li);
			}
		}
	}

	if (tbs.GetCount() > 1)
		qsort(tbs.GetData(), tbs.GetCount(), sizeof(LAYInfo), qsortFunc);
	if (infos.GetCount() > 1)
		qsort(infos.GetData(), infos.GetCount(), sizeof(LAYInfo), qsortFunc);
	if (infos2.GetCount() > 1)
		qsort(infos2.GetData(), infos2.GetCount(), sizeof(LAYInfo), qsortFunc);


	//CDlgTables dt(pWS, pTables);
	//if (dt.DoModal() != IDOK)
	//	return S_OK;

	SGSFCOMS::IEnvelopePtr pMapBound;
	SGSFCOMS::ISpatialReferencePtr pSR;
	if (m_pApp)
	{
		SGCore::IDisplayTransformationPtr pDT = m_pApp->GetMapView()->GetDisplay()->GetDisplayTransformation();
		pSR = pDT->GetSpatialReference();
	}
	SGCore::IMapPtr pMap = Parent->GetMap();
	SGCore::ILayerGroupPtr pLG;
	SuperGIS3::ITableSourceControlPtr pTSC = m_pApp->Legend->TableSourceControl;

	SGMap::IGroupLayerPtr pGroup;
	CString curGLName;
	SGCore::ILayerGroupPtr pLG2;
	SGCore::IMapLayerPtr play;

	if (infos.GetCount() > 0 || infos2.GetCount()>0)
	{
		SGFileGDB::IGDBGroupLayerPtr gdbgl = pGWS->CreateGroupLayer(VARIANT_TRUE);// (SGFileGDB::CLSID_GDBGroupLayer);
																				  //SGCore::IGDBClassPtr gcl = gdbgl;
																				  //if (gcl)
																				  //{
																				  //	VARIANT_BOOL b;
																				  //	gcl->raw_Connect(_bstr_t(m_curPath), &b);
																				  //}
		pGroup = gdbgl;
		pLG = pGroup;
		//play = pGroup;
		//play->PutName(_bstr_t(m_curPath));
		//int ti = m_curPath.ReverseFind(L'\\');
		//if (ti<0)
		//	ti= m_curPath.ReverseFind(L'/');
		//if (ti<0)
		//	play->PutTitle(_bstr_t(m_curPath));
		//else
		//	play->PutTitle(_bstr_t(m_curPath.Mid(ti+1)));
	}

	bool bRefresh = false;

	LAYInfo* pArTables;
	for (int i = infos.GetCount() - 1; i >= 0; i--)
	{
		pArTables = &(infos.GetAt(i));
		SGCore::IFeatureClassPtr pFC = pArTables->pUnk;
		CString tname = pArTables->name;
		SGCore::IFeatureLayerPtr pLayer(SGMap::CLSID_FeatureLayer);
		pLayer->putref_FeatureClass(pFC);
		pLayer->put_Name(_bstr_t(tname));
		pLayer->put_Title(_bstr_t(tname));

		SGCore::IGeoDatasetPtr pGd = pLayer;
		if (pGd)
		{
			SGSFCOMS::IEnvelopePtr pBound = pGd->GetExtent(pSR);
			if (pBound)
			{
				if (!(_isnan(pBound->minX) || (pBound->minX == 0 && pBound->minX == pBound->maxX && pBound->minY == pBound->maxY)))
				{
					if (pSR == NULL)
					{
						pSR = pGd->GetSpatialReference();
						pBound->PutRefSpatialReference(pSR);
					}
					if (pMapBound == NULL)
					{
						pMapBound = pBound;
					}
					else
					{
						if (pBound->minX < pMapBound->minX)
							pMapBound->minX = pBound->minX;
						if (pBound->maxX > pMapBound->maxX)
							pMapBound->maxX = pBound->maxX;
						if (pBound->minY < pMapBound->minY)
							pMapBound->minY = pBound->minY;
						if (pBound->maxY > pMapBound->maxY)
							pMapBound->maxY = pBound->maxY;
					}
				}
			}
		}
		pLG->AddLayer(pLayer);
		bRefresh = true;
	}
	pArTables = infos2.GetData();
	for (int i = infos2.GetCount() - 1; i >= 0; i--)
	{
		pArTables = &(infos2.GetAt(i));
		SGCore::IFeatureClassPtr pFC = pArTables->pUnk;
		{
			CString tname = pArTables->name;
			int ti = tname.FindOneOf(L"\\/");
			if (ti > 0)
			{
				if (tname.Left(ti).CompareNoCase(curGLName) != 0)
				{
					if (pLG2)
					{
						play = pLG2;
						pLG->AddLayer(play);
					}
					SGMap::IGroupLayerPtr pGL(SGMap::CLSID_GroupLayer);
					pLG2 = pGL;
					curGLName = tname.Left(ti);
					play = pGL;
					play->PutName(_bstr_t(curGLName));
					play->PutTitle(_bstr_t(curGLName));
				}
				tname = tname.Mid(ti + 1);
			}
			else
			{
				if (pLG2)
				{
					play = pLG2;
					pLG->AddLayer(play);
				}
				pLG2 = NULL;
			}

			SGCore::IFeatureLayerPtr pLayer(SGMap::CLSID_FeatureLayer);
			pLayer->putref_FeatureClass(pFC);
			pLayer->put_Name(_bstr_t(tname));
			pLayer->put_Title(_bstr_t(tname));

			SGCore::IGeoDatasetPtr pGd = pLayer;
			if (pGd)
			{
				SGSFCOMS::IEnvelopePtr pBound = pGd->GetExtent(pSR);
				if (pBound)
				{
					if (!(_isnan(pBound->minX) || (pBound->minX == 0 && pBound->minX == pBound->maxX && pBound->minY == pBound->maxY)))
					{
						if (pSR == NULL)
						{
							pSR = pGd->GetSpatialReference();
							pBound->PutRefSpatialReference(pSR);
						}
						if (pMapBound == NULL)
						{
							pMapBound = pBound;
						}
						else
						{
							if (pBound->minX < pMapBound->minX)
								pMapBound->minX = pBound->minX;
							if (pBound->maxX > pMapBound->maxX)
								pMapBound->maxX = pBound->maxX;
							if (pBound->minY < pMapBound->minY)
								pMapBound->minY = pBound->minY;
							if (pBound->maxY > pMapBound->maxY)
								pMapBound->maxY = pBound->maxY;
						}
					}
				}
			}
			if (pLG2)
				pLG2->AddLayer(pLayer);
			else
				pLG->AddLayer(pLayer);

			bRefresh = true;
		}
	}

	for (int i = tbs.GetCount() - 1; i >= 0; i--)// �� Table
	{
		SGCore::ITablePtr pTable = tbs[i].pUnk;
		if (pTable)
		{
			SGDBTables::ITableSourcePtr pTS(SGDBTables::CLSID_TableSource);
			pTS->Table = pTable;
			//pTS->Name = name;

			SGDBTables::IDBConnectionPtr pConn = pTS;
			if (pConn)
				pConn->ConnectionName = (_bstr_t)dd.m_strPath;

			pTSC->AddTableSource(pTS);
		}
	}

	if (bRefresh && m_pApp)
	{
		play = pGroup;
		if (play)
		{
			pLG = pMap;
			pLG->AddLayer(play);
		}
		if (pMapBound)
		{
			SGCore::IDisplayTransformationPtr pDT = m_pApp->GetMapView()->GetDisplay()->GetDisplayTransformation();
			pDT->PutRefBoundary(pMapBound);
		}
		m_pApp->GetMapView()->raw_Refresh(0);
	}

	return S_OK;
}
