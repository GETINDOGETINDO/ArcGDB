#include "stdafx.h"
#include "SGUtils.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define PATH_ERROR			-1
#define PATH_NOT_FOUND		0
#define PATH_IS_FILE		1
#define PATH_IS_FOLDER		2

BOOL FileExists(LPCTSTR szPath, BOOL bDir)
{
	DWORD dwAttrib = GetFileAttributes(szPath);
	if (dwAttrib != INVALID_FILE_ATTRIBUTES)
	{
		if ((dwAttrib & FILE_ATTRIBUTE_DIRECTORY))
			return bDir;
		else
			return !bDir;
	}
	return FALSE;
}

void PreparePath(CString &sPath)
{
	if (sPath.Right(1) != _T("\\")) sPath += _T("\\");
}
//folder�������ϧ�u�i���i�L,���i��
int CheckPath(LPCTSTR sPath)
{
	DWORD dwAttr = GetFileAttributes(sPath);
	if (dwAttr == 0xffffffff)
	{
		if (GetLastError() == ERROR_FILE_NOT_FOUND || GetLastError() == ERROR_PATH_NOT_FOUND)
			return PATH_NOT_FOUND;

		return PATH_ERROR;
	}
	if (dwAttr & FILE_ATTRIBUTE_DIRECTORY) return PATH_IS_FOLDER;
	return PATH_IS_FILE;
}

BOOL OutPathExist(LPCTSTR szPath, BOOL bCreate)
{
	DWORD ret;
	ret = GetFileAttributes(szPath);
	//TRACE("OutPathExist ret=%d\n", ret);
	if (ret != 0xffffffff && (ret & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		return TRUE;

	if (bCreate) {
		if (CreateDirectory(szPath, NULL) == 0) {
			ret = GetLastError();
			//TRACE("CreateDirectory ok ret=%d\n", ret);
			if (ret == ERROR_ALREADY_EXISTS)
				return TRUE;

		}
		else
			return TRUE;

		//SHCreateDirectoryEx �i�ئh��path shlobj.h
		ret = SHCreateDirectoryEx(0, szPath, 0);
		//TRACE("bCreate ret=%d\n", ret);
		if (ret == ERROR_SUCCESS || ret == ERROR_ALREADY_EXISTS)
			return TRUE;
	}
	return FALSE;
}

//bEmptyFolder=TRUE������sub folder�]�����Ū�.
BOOL IsFolderEmpty(LPCTSTR sPathName, BOOL bEmptyFolder)
{
	if (CheckPath(sPathName) == PATH_IS_FOLDER)
	{
		CFileFind ff;
		CString sPath = sPathName;
		PreparePath(sPath);
		sPath += _T("*.*");
		BOOL bRes = ff.FindFile(sPath);
		if (bRes)
		{
			BOOL bEmpty = TRUE;
			while (bRes)
			{
				bRes = ff.FindNextFile();
				if (ff.IsDots())
					continue;

				if (ff.IsDirectory())
				{
					if (!bEmptyFolder)
					{
						bEmpty = FALSE;
						break;
					}
					if (!IsFolderEmpty(ff.GetFilePath(), bEmptyFolder))
					{
						bEmpty = FALSE;
						break;
					}
				}
				else
				{
					bEmpty = FALSE;
					break;
				}
			}
			ff.Close();
			return bEmpty;
		}
		ff.Close();
		return TRUE;
	}
	return FALSE;
}

CGDBList g_gdbList;

CString LoadIDString(UINT nID)
{
	CString str;
	//if (theApp.GetXMLResAgent())
	//{
	//	_bstr_t bstr = theApp.GetXMLResAgent()->LoadIDString(nID);
	//	if (bstr.length() > 0)
	//		str = (LPCTSTR)bstr;
	//}
	//if (str.IsEmpty())
		str.LoadString(nID);

	return str;
}

CString LoadXMLIDString(UINT nID, UINT nStringTableID)
{
	//if (!theApp.GetXMLResAgent())
	//{
	//	if (nStringTableID != 0)
	//		return LoadIDString(nStringTableID);
	//	else
	//		return LoadIDString(nID);
	//}
	//_bstr_t bstr = theApp.GetXMLResAgent()->LoadIDString(nID);
	//if (bstr.length() > 0)
	//{
	//	CString str = (LPCTSTR)bstr;
	//	return str;
	//}
	return LoadIDString(nID);
}

void RetrieveLayerCollection(SGCore::ILayerGroupPtr pLG, CArray<SGCore::IMapLayerPtr, SGCore::IMapLayerPtr>* pArLayer, BOOL bIncludeSubTree)
{
	if (pLG == NULL)
		return;

	long cnt;
	pLG->get_LayerCount(&cnt);

	SGCore::IFeatureLayerPtr pFL;
	for (int i = 0; i < cnt; i++)
	{
		SGCore::IMapLayerPtr pLayer;
		pLG->get_Layer(i, &pLayer);

		SGCore::ILayerGroupPtr pSub = pLayer;
		if (pSub)
		{
			//if (bIncludeGroup)
			//	pArLayer->Add(pLayer);
			if (bIncludeSubTree)
				RetrieveLayerCollection(pSub, pArLayer, bIncludeSubTree);
		}
		else
		{
			pFL = pLayer;
			if (pFL)	//only feature layer
				pArLayer->Add(pLayer);
		}
	}
}


int qsortFunc(const void *arg1, const void *arg2)
{
	LAYInfo* p1 = (LAYInfo*)arg1;
	LAYInfo* p2 = (LAYInfo*)arg2;

	CString name1 = p1->name;
	CString name2 = p2->name;
	int t1 = name1.Find(L'\\');
	if (t1<0)
		t1 = name1.Find(L'/');
	int t2 = name2.Find(L'\\');
	if (t2<0)
		t2 = name2.Find(L'/');

	if (t1 > 0)
	{
		if (t2 > 0)
		{
			int ci = name1.Left(t1).CompareNoCase(name2.Left(t2));
			if (ci == 0)
			{
				if (p1->type == p2->type)
					return name1.Mid(t1 + 1).CompareNoCase(name2.Mid(t2 + 1));
				return (p1->type - p2->type);
			}
			return ci;
		}
		else
			return 1;
	}
	else
	{
		if (t2 > 0)
			return -1;

		if (p1->type == p2->type)
			return name1.CompareNoCase(name2);
		return (p1->type - p2->type);
	}
}


CGDBList::CGDBList()
{
	m_bDirty = false;
}

CGDBList::~CGDBList()
{
	Clear();
}

void CGDBList::Clear()
{
	m_gdbs.RemoveAll();
	m_gdbs.FreeExtra();
	m_bDirty = false;
}


SGFileGDB::IGDBWorkspacePtr CGDBList::GetGDB(LPCTSTR fname, BOOL bAdd)
{
	int i = FindGDBindex(fname);
	if (i >= 0)
	{
		while (i >= 10000)
			i -= 10000;
		m_gdbs[i].nRef++;
		return m_gdbs[i].pGWS;
	}
	if (bAdd)
	{
		SGFileGDB::IGDBWorkspacePtr pGWS(SGFileGDB::CLSID_GDBWorkspace);
		if (pGWS->Open(_bstr_t(fname)))
		{
			GDBInfo info;
			info.nRef = 1;
			_tcscpy(info.name, fname);
			info.pGWS = pGWS;
			m_gdbs.Add(info);
			m_bDirty = true;
			return pGWS;
		}
	}
	return NULL;
}


int CGDBList::RemoveGDB(SGFileGDB::IGDBWorkspacePtr pGWS, LPCTSTR fname)
{
	if (fname)
	{
		int i = FindGDBindex(fname);
		if (i >= 0)
		{
			while (i >= 10000)
				i -= 10000;

			m_bDirty = true;
			m_gdbs.RemoveAt(i);
			return i;
		}
	}
	if (pGWS)
	{
		for (int i = 0; i < m_gdbs.GetCount(); i++)
		{
			if (m_gdbs[i].pGWS == pGWS)
			{
				m_bDirty = true;
				m_gdbs.RemoveAt(i);
				return i;
			}
		}
	}
	return -1;
}

int CGDBList::FindGDBindex(LPCTSTR fname) 
{
	for (int i = 0; i < m_gdbs.GetCount(); i++)
	{
		if (_tcsicmp(fname, m_gdbs[i].name) == 0)
			return i;
	}
	{
		CString buf = fname;
		int fi = buf.ReverseFind(L'\\');
		if (fi < 0)
			fi = buf.ReverseFind(L'/');

		if (fi > 0)
		{
			buf = buf.Left(fi);
			int fi2 = buf.ReverseFind(L'\\');
			if (fi2 < 0)
				fi2 = buf.ReverseFind(L'/');
			for (int i = 0; i < m_gdbs.GetCount(); i++)
			{
				if (_tcsncmp(fname, m_gdbs[i].name, fi) == 0)
					return 10000 + i;		//�Y��  path\\table
				if (fi2 > 0)
				{
					if (_tcsncmp(fname, m_gdbs[i].name, fi2) == 0)
						return 20000 + i;  //�Y��  path\\dataset\\table
				}
			}
		}
	}
	return -1;
}

int CGDBList::FindGDB(SGFileGDB::IGDBWorkspacePtr pGWS)
{
	for (int i = 0; i < m_gdbs.GetCount(); i++)
	{
		if (m_gdbs[i].pGWS == pGWS)
			return i;
	}
	return -1;
}

SGCore::IFeatureClassPtr SGOpenFeatureClass(CString strOutPath, SGSFCOMS::ISpatialReferencePtr pSpaRef)
{
	if (strOutPath.Right(4).CompareNoCase(L".geo") == 0)
	{
		SGDataAccess::IGeoFileFeatureClassPtr pNewGeoCls(SGDataAccess::CLSID_GeoFileFeatureClass);
		if (pNewGeoCls->OpenFromFile((_bstr_t)strOutPath))
			return pNewGeoCls;
	}
	else if (strOutPath.Right(4).CompareNoCase(L".shp") == 0)
	{
		SGDataAccess::IShapeFileFeatureClassPtr pNewShpCls(SGDataAccess::CLSID_ShapeFileFeatureClass);
		if (pNewShpCls->OpenFromFile((_bstr_t)strOutPath))
			return pNewShpCls;
	}
	{
		int pos = strOutPath.ReverseFind('\\');
		if (pos>0)
		{
			CString strLocation = strOutPath.Left(pos);
			CString strName = strOutPath.Right(strOutPath.GetLength() - pos - 1);

			SGDataSelect::IDataSelector2Ptr pSel(SGDataSelect::CLSID_DataSelector2);
			SGCore::IDBWorkspacePtr pWS = pSel->GetGDBWorkspace(strLocation.AllocSysString());
			if (pWS)
				return pWS->OpenTable(strName.AllocSysString(), _T("GEOMETRY"), pWS->FieldGeometryType(strName.AllocSysString(), _T("GEOMETRY")));
			//return pWS->OpenTable(strName.AllocSysString(), _T(""), SGCore::SGO_GT_Unknown);
		}
	}
	return NULL;
}

void SetupGDBFields(SGCore::IFieldsPtr pFields, SGCore::IFieldsPtr pSrcFields, BOOL bOnlyTable)
{
	SGCore::IFieldsEditPtr pFE = pFields;
	long nFields;
	pSrcFields->get_FieldCount(&nFields);

	long geomFldi = -1;
	SGCore::IField2Ptr pFld2;
	for (int i = 0; i < nFields; i++)
	{
		SGCore::IFieldPtr pSrcField;
		pSrcFields->get_Field(i, &pSrcField);

		SGCore::IFieldPtr pField(SGDataAccess::CLSID_Field);
		BSTR bsName;
		pSrcField->get_Name(&bsName);
		pField->put_Name(bsName);

		SGCore::SGOFieldType eType;
		pSrcField->get_Type(&eType);
		if ((eType & SGCore::SGO_FT_IUnknown) == SGCore::SGO_FT_IUnknown || (eType & SGCore::SGO_FT_IDispatch) == SGCore::SGO_FT_IDispatch)
		{
			if (bOnlyTable)		//geometry������
				continue;
			CString fldName = bsName;
			if (fldName.CompareNoCase(_T("GEOMETRY")) == 0)
				geomFldi = i;
		}
		//if (eType == SGCore::SGO_FT_Decimal) // type��decimal,�N�Hdouble�B�z
		//	eType = SGCore::SGO_FT_Double;
		pField->put_Type(eType);

		long lLen;
		pSrcField->get_Length(&lLen);
		pField->put_Length(lLen);
		pFld2 = pSrcField;
		pFld2->get_Precision(&lLen);
		pFld2 = pField;
		pFld2->put_Precision(lLen);

		pFE->raw_AddField(pField);
	}
	if (!bOnlyTable && geomFldi == -1)
	{
		SGCore::IFieldPtr pGeometryFld(SGDataAccess::CLSID_Field);
		pGeometryFld->put_Name(_T("GEOMETRY"));
		pGeometryFld->put_Type(SGCore::SGO_FT_IUnknown);
		pFE->raw_AddField(pGeometryFld);
	}
}

void CopyRecords(IUnknownPtr pDest, SGCore::IFieldsPtr pSrcFields, IUnknownPtr pSrcCursor, BOOL bOnlyTable, BOOL bEditTask)
{
	SGCore::IEditTaskPtr pEditTask = pDest;
	if (bEditTask && pEditTask)
	{
		VARIANT_BOOL retBool;
		pEditTask->raw_BeginEdit(&retBool);
	}

	SGCore::IFieldsPtr pFields;
	SGCore::IFeatureClassEditPtr pFCEdit = pDest;
	SGCore::ITableEditPtr pTE = pDest;
	if (pFCEdit)
		pFCEdit->get_Fields(&pFields);
	else
		pTE->get_Fields(&pFields);

	long nFields = 0;
	if (pFields)
		pFields->get_FieldCount(&nFields);
	long fi;
	CArray<long> fldsi;		//��ؼ�field name������pSrcFields��������
	if (nFields>0)
	{
		long sn = pSrcFields->GetFieldCount();
		fldsi.SetSize(nFields, 1);
		for (long i = 0; i < nFields; i++)
		{
			fi = -1;
			pSrcFields->raw_Find(pFields->GetField(i)->Name, &fi);
			if (fi < 0 && sn == nFields)
				fi = i;
			fldsi.SetAt(i, fi);
		}
		for (long i = 0; i < nFields; i++)
		{
			if (fldsi[i] < 0)
			{
				long fi = i;
				if (fi >= sn)
					fi = sn - 1;

				CString fname = pFields->GetField(i)->Name;
				for (int k = 0; k < 3; k++)
				{
					CString fname1 = pSrcFields->GetField(fi)->Name;
					if ((fname.GetLength() - fname1.GetLength()) < 2)
					{
						if (fname1.Find(fname) >= 0)
						{
							fldsi[i] = fi;
							break;
						}
					}
					if (k == 0)
					{
						fi--;
						if (fi < 0)
						{
							fi = 1;
							k = 1;
						}
					}
					else if (k == 1)
					{
						fi += 2;
						if (fi >= sn)
							break;
					}
				}
			}
		}
	}
	SGCore::IFeatureEditPtr pFEdit;
	SGCore::ITableRowEditPtr pREdit;
	VARIANT field;
	field.vt = VT_I4;
	field.lVal = 0;
	SGCore::IFeatureCursorPtr pFCur = pSrcCursor;

	double r = 0;
	int i = 0;

	long cur_pos = -1, tick_cur = GetTickCount();
	if (pFCur)
	{
		SGCore::IFeaturePtr pSrcFeature = pFCur->NextFeature();
		while (pSrcFeature)
		{
			if (pFCEdit)
			{
				pFCEdit->raw_CreateFeature(&pFEdit);
			}
			else
			{
				pTE->raw_CreateRow(&pREdit);
			}
			for (long i = 0; i < nFields; i++)
			{
				fi = fldsi.GetAt(i);
				if (fi >= 0)
				{
					field.lVal = fi;
					_variant_t v;
					pSrcFeature->get_Value(field, &v);
					if (v.vt == VT_INT)			//�Y��DB��VT_INT�L�k���T���ȵ�ADO�B�z,�|���Ū�
						v.ChangeType(VT_I4);
					field.lVal = i;
					if (pFCEdit)
						pFEdit->put_Value(field, v);
					else
						pREdit->put_Value(field, v);
				}
			}
			if (pFCEdit)
			{
				if (!bOnlyTable)
				{
					SGSFCOMS::IGeometryPtr pGeo;
					pSrcFeature->get_Geometry(&pGeo);
					if (pGeo)
						pFEdit->put_Geometry(pGeo);		//ken�n���put_Value�]�w,#3465
				}
				pFEdit->raw_Update();
			}
			else
				pREdit->raw_Update();

			pSrcFeature = NULL;
			pSrcFeature = pFCur->NextFeature();
		}
	}
	else
	{
		SGCore::ITableCursorPtr pTCur = pSrcCursor;

		SGCore::ITableRowPtr pSrcRow = pTCur->NextRow();
		while (pSrcRow)
		{
			if (pTE)
				pTE->raw_CreateRow(&pREdit);
			else
				pFCEdit->raw_CreateFeature(&pFEdit);

			for (long i = 0; i < nFields; i++)
			{
				fi = fldsi.GetAt(i);
				if (fi >= 0)
				{
					field.lVal = fi;
					_variant_t v;
					pSrcRow->get_Value(field, &v);
					if (v.vt == VT_INT)			//�Y��DB��VT_INT�L�k���T���ȵ�ADO�B�z,�|���Ū�
						v.ChangeType(VT_I4);
					field.lVal = i;
					if (pTE)
						pREdit->put_Value(field, v);
					else
						pFEdit->put_Value(field, v);
				}
			}
			if (pTE)
				pREdit->raw_Update();
			else
				pFEdit->raw_Update();

			pSrcRow = NULL;
			pSrcRow = pTCur->NextRow();
		}
	}
	if (bEditTask && pEditTask)
		pEditTask->raw_EndEdit();
}
