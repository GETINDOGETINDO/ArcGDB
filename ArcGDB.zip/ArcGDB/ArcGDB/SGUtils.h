#pragma once
#include <math.h>

BOOL FileExists(LPCTSTR szPath, BOOL bDir);
void PreparePath(CString &sPath);
int CheckPath(LPCTSTR sPath);
BOOL OutPathExist(LPCTSTR szPath, BOOL bCreate);
BOOL IsFolderEmpty(LPCTSTR sPathName, BOOL bEmptyFolder);

struct GDBInfo
{
	int nRef;
	SGFileGDB::IGDBWorkspacePtr pGWS;
	TCHAR name[256];
};

struct LAYInfo
{
	int type;	//�̥γ~��FC�̬�1,2,3(+1000/2000), ��name�Ϥ��̬�(10*gdbIndex+listtype(0~5))
	IUnknownPtr pUnk;	//�̥γ~�|��IGDBWorkspacePtr �� SGCore::IFeatureClassPtr
	TCHAR name[256];
};

class CGDBList
{
public:
	CGDBList();
	~CGDBList();

	SGFileGDB::IGDBWorkspacePtr GetGDB(LPCTSTR fname, BOOL bAdd);
	int RemoveGDB(SGFileGDB::IGDBWorkspacePtr pGWS, LPCTSTR fname);
	void Clear();
	bool IsDirty() { return m_bDirty; };

	int GetGDBCount() { return m_gdbs.GetCount(); };
	GDBInfo* GetGDB(int index) { return (index>=0 && index<m_gdbs.GetCount()) ? &(m_gdbs[index]) : NULL; };
	int FindGDB(SGFileGDB::IGDBWorkspacePtr pGWS);
	int FindGDBindex(LPCTSTR fname);

private:
	CArray<GDBInfo> m_gdbs;
	bool m_bDirty;
};

extern CGDBList g_gdbList;

int qsortFunc(const void *arg1, const void *arg2);

CString LoadIDString(UINT nID);
CString LoadXMLIDString(UINT nID, UINT nStringTableID = 0);

void RetrieveLayerCollection(SGCore::ILayerGroupPtr pLG, CArray<SGCore::IMapLayerPtr, SGCore::IMapLayerPtr>* pArLayer, BOOL bIncludeSubTree=TRUE);

SGCore::IFeatureClassPtr SGOpenFeatureClass(CString strOutPath, SGSFCOMS::ISpatialReferencePtr pSpaRef);
void SetupGDBFields(SGCore::IFieldsPtr pFields, SGCore::IFieldsPtr pSrcFields, BOOL bOnlyTable);
void CopyRecords(IUnknownPtr pDest, SGCore::IFieldsPtr pSrcFields, IUnknownPtr pSrcCursor, BOOL bOnlyTable, BOOL bEditTask);

