#pragma once
#include "afxcmn.h"

#include "SGUtils.h"
// CDlgGDBList ��ܤ��

class CDlgGDBList : public CDialog
{
	DECLARE_DYNAMIC(CDlgGDBList)

public:
	CDlgGDBList(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgGDBList();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_GDBLIST };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

	CRect	m_rcInit;
	void Sort(HTREEITEM hParent);
	CImageList m_imageList;
	CArray<LAYInfo> m_sels;
	void clearTreeAllSelected();
	void addSelectItem(HTREEITEM &hItem, LAYInfo& lay);
	void traverseSelect(HTREEITEM &hItem, bool bClear);
	int GetSelectItems();
	void GetAllSelectedInfo(CArray<LAYInfo>& allSels);
	void traverseSub(HTREEITEM& hItem, CArray<LAYInfo>& lays, bool bsel);

public:
	CTreeCtrl m_tree;
	virtual BOOL OnInitDialog();

	void Reload();
	afx_msg void OnNMRClickTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnBegindragTree(NMHDR *pNMHDR, LRESULT *pResult);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedOk();
};
