// DlgCreate.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgCreate.h"
//#include "afxdialogex.h"
#include "DirDialog.h"
#include "SGUtils.h"



// CDlgCreate ��ܤ��
CString s_createGDB=L"";

IMPLEMENT_DYNAMIC(CDlgCreate, CDialog)

CDlgCreate::CDlgCreate(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CREATE, pParent)
	, m_name(_T(""))
	, m_outputPath(_T(""))
{

}

CDlgCreate::~CDlgCreate()
{
}

void CDlgCreate::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_NAME, m_name);
	DDX_Text(pDX, IDC_PATH, m_outputPath);
}


BEGIN_MESSAGE_MAP(CDlgCreate, CDialog)
	ON_BN_CLICKED(IDC_BTNPATH, &CDlgCreate::OnBnClickedBtnpath)
	ON_BN_CLICKED(IDOK, &CDlgCreate::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgCreate �T���B�z�`��


void CDlgCreate::OnBnClickedBtnpath()
{
	UpdateData();
	CDirDialog dd;
#ifdef _DEBUG
	if (m_outputPath.IsEmpty())
		m_outputPath = L"f:\\test\\gdb";
#endif

	dd.m_strSelDir = m_outputPath;
	if (!dd.DoBrowse(AfxGetMainWnd()))
		return ;

	m_outputPath = dd.m_strPath;
	UpdateData(FALSE);
}


void CDlgCreate::OnBnClickedOk()
{
	UpdateData();
	m_name = m_name.Trim();
	m_outputPath = m_outputPath.Trim();
	if (m_name.IsEmpty() || m_outputPath.IsEmpty())
	{
		MessageBox(L"Must input data");
		return;
	}
	if (!FileExists(m_outputPath, TRUE))
	{
		if (MessageBox(L"Path not exist, Do you want to create?", 0, MB_YESNO) == IDNO)
			return;

		if (!OutPathExist(m_outputPath, TRUE))
		{
			MessageBox(L"Create path error!");
			return;
		}
	}
	if (m_name.Right(4).CompareNoCase(L".gdb") != 0)
		m_name += L".gdb";
	UpdateData(FALSE);

	CString buf;
	buf.Format(L"%s\\%s", m_outputPath, m_name);
	if (FileExists(buf, TRUE) && !IsFolderEmpty(buf, FALSE))
	{
		MessageBox(L"The name folder is not empty!");
		return;
	}
	RemoveDirectory(buf);
	SGFileGDB::IGDBWorkspacePtr pGWS(SGFileGDB::CLSID_GDBWorkspace);
	if (pGWS->Create(_bstr_t(buf)))
	{
		s_createGDB = buf;
		CDialog::OnOK();
	}
	else
	{
		buf += L"\r\nCreate GDB failure!";
		MessageBox(buf);
	}
}
