

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Tue Oct 01 10:50:17 2019
 */
/* Compiler settings for ArcGDB.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ArcGDB_h__
#define __ArcGDB_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IExtBar_FWD_DEFINED__
#define __IExtBar_FWD_DEFINED__
typedef interface IExtBar IExtBar;

#endif 	/* __IExtBar_FWD_DEFINED__ */


#ifndef __IExtButton_FWD_DEFINED__
#define __IExtButton_FWD_DEFINED__
typedef interface IExtButton IExtButton;

#endif 	/* __IExtButton_FWD_DEFINED__ */


#ifndef __IBtnOpen_FWD_DEFINED__
#define __IBtnOpen_FWD_DEFINED__
typedef interface IBtnOpen IBtnOpen;

#endif 	/* __IBtnOpen_FWD_DEFINED__ */


#ifndef __IBtnCreate_FWD_DEFINED__
#define __IBtnCreate_FWD_DEFINED__
typedef interface IBtnCreate IBtnCreate;

#endif 	/* __IBtnCreate_FWD_DEFINED__ */


#ifndef __IBtnImport_FWD_DEFINED__
#define __IBtnImport_FWD_DEFINED__
typedef interface IBtnImport IBtnImport;

#endif 	/* __IBtnImport_FWD_DEFINED__ */


#ifndef __ExtBar_FWD_DEFINED__
#define __ExtBar_FWD_DEFINED__

#ifdef __cplusplus
typedef class ExtBar ExtBar;
#else
typedef struct ExtBar ExtBar;
#endif /* __cplusplus */

#endif 	/* __ExtBar_FWD_DEFINED__ */


#ifndef __ExtButton_FWD_DEFINED__
#define __ExtButton_FWD_DEFINED__

#ifdef __cplusplus
typedef class ExtButton ExtButton;
#else
typedef struct ExtButton ExtButton;
#endif /* __cplusplus */

#endif 	/* __ExtButton_FWD_DEFINED__ */


#ifndef __BtnOpen_FWD_DEFINED__
#define __BtnOpen_FWD_DEFINED__

#ifdef __cplusplus
typedef class BtnOpen BtnOpen;
#else
typedef struct BtnOpen BtnOpen;
#endif /* __cplusplus */

#endif 	/* __BtnOpen_FWD_DEFINED__ */


#ifndef __BtnCreate_FWD_DEFINED__
#define __BtnCreate_FWD_DEFINED__

#ifdef __cplusplus
typedef class BtnCreate BtnCreate;
#else
typedef struct BtnCreate BtnCreate;
#endif /* __cplusplus */

#endif 	/* __BtnCreate_FWD_DEFINED__ */


#ifndef __BtnImport_FWD_DEFINED__
#define __BtnImport_FWD_DEFINED__

#ifdef __cplusplus
typedef class BtnImport BtnImport;
#else
typedef struct BtnImport BtnImport;
#endif /* __cplusplus */

#endif 	/* __BtnImport_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IExtBar_INTERFACE_DEFINED__
#define __IExtBar_INTERFACE_DEFINED__

/* interface IExtBar */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IExtBar;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C7EE87CF-300B-43F5-B744-DD4B7452C9DC")
    IExtBar : public IDispatch
    {
    public:
    };
    
    
#else 	/* C style interface */

    typedef struct IExtBarVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IExtBar * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IExtBar * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IExtBar * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IExtBar * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IExtBar * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IExtBar * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IExtBar * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } IExtBarVtbl;

    interface IExtBar
    {
        CONST_VTBL struct IExtBarVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IExtBar_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IExtBar_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IExtBar_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IExtBar_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IExtBar_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IExtBar_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IExtBar_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IExtBar_INTERFACE_DEFINED__ */


#ifndef __IExtButton_INTERFACE_DEFINED__
#define __IExtButton_INTERFACE_DEFINED__

/* interface IExtButton */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IExtButton;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1783B87F-D9A0-4A94-B684-816F635E589B")
    IExtButton : public IDispatch
    {
    public:
    };
    
    
#else 	/* C style interface */

    typedef struct IExtButtonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IExtButton * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IExtButton * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IExtButton * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IExtButton * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IExtButton * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IExtButton * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IExtButton * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } IExtButtonVtbl;

    interface IExtButton
    {
        CONST_VTBL struct IExtButtonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IExtButton_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IExtButton_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IExtButton_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IExtButton_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IExtButton_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IExtButton_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IExtButton_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IExtButton_INTERFACE_DEFINED__ */


#ifndef __IBtnOpen_INTERFACE_DEFINED__
#define __IBtnOpen_INTERFACE_DEFINED__

/* interface IBtnOpen */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IBtnOpen;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2440051E-09FB-4E04-9DBA-F6B60D4BAC8D")
    IBtnOpen : public IDispatch
    {
    public:
    };
    
    
#else 	/* C style interface */

    typedef struct IBtnOpenVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IBtnOpen * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IBtnOpen * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IBtnOpen * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IBtnOpen * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IBtnOpen * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IBtnOpen * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IBtnOpen * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } IBtnOpenVtbl;

    interface IBtnOpen
    {
        CONST_VTBL struct IBtnOpenVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBtnOpen_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IBtnOpen_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IBtnOpen_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IBtnOpen_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IBtnOpen_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IBtnOpen_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IBtnOpen_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IBtnOpen_INTERFACE_DEFINED__ */


#ifndef __IBtnCreate_INTERFACE_DEFINED__
#define __IBtnCreate_INTERFACE_DEFINED__

/* interface IBtnCreate */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IBtnCreate;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("AABFCE8E-CC9B-4CFC-A292-45626FAE611E")
    IBtnCreate : public IDispatch
    {
    public:
    };
    
    
#else 	/* C style interface */

    typedef struct IBtnCreateVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IBtnCreate * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IBtnCreate * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IBtnCreate * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IBtnCreate * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IBtnCreate * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IBtnCreate * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IBtnCreate * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } IBtnCreateVtbl;

    interface IBtnCreate
    {
        CONST_VTBL struct IBtnCreateVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBtnCreate_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IBtnCreate_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IBtnCreate_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IBtnCreate_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IBtnCreate_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IBtnCreate_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IBtnCreate_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IBtnCreate_INTERFACE_DEFINED__ */


#ifndef __IBtnImport_INTERFACE_DEFINED__
#define __IBtnImport_INTERFACE_DEFINED__

/* interface IBtnImport */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IBtnImport;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9C3867CB-CB29-4D7F-8399-1C49AC7B879E")
    IBtnImport : public IDispatch
    {
    public:
    };
    
    
#else 	/* C style interface */

    typedef struct IBtnImportVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IBtnImport * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IBtnImport * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IBtnImport * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IBtnImport * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IBtnImport * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IBtnImport * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IBtnImport * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } IBtnImportVtbl;

    interface IBtnImport
    {
        CONST_VTBL struct IBtnImportVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBtnImport_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IBtnImport_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IBtnImport_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IBtnImport_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IBtnImport_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IBtnImport_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IBtnImport_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IBtnImport_INTERFACE_DEFINED__ */



#ifndef __ArcGDBLib_LIBRARY_DEFINED__
#define __ArcGDBLib_LIBRARY_DEFINED__

/* library ArcGDBLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ArcGDBLib;

EXTERN_C const CLSID CLSID_ExtBar;

#ifdef __cplusplus

class DECLSPEC_UUID("19565592-19BA-427E-AF31-5123A0B176CE")
ExtBar;
#endif

EXTERN_C const CLSID CLSID_ExtButton;

#ifdef __cplusplus

class DECLSPEC_UUID("74F51DA6-C7C7-4556-AD97-A6CED6408C34")
ExtButton;
#endif

EXTERN_C const CLSID CLSID_BtnOpen;

#ifdef __cplusplus

class DECLSPEC_UUID("42C5D0AE-708E-4998-8873-4C342C6EF0C2")
BtnOpen;
#endif

EXTERN_C const CLSID CLSID_BtnCreate;

#ifdef __cplusplus

class DECLSPEC_UUID("5146E3BC-8FF6-4857-B56E-3BEC7F4E3497")
BtnCreate;
#endif

EXTERN_C const CLSID CLSID_BtnImport;

#ifdef __cplusplus

class DECLSPEC_UUID("925EDFE4-0145-4817-9F45-AD6EDC2E13FA")
BtnImport;
#endif
#endif /* __ArcGDBLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


