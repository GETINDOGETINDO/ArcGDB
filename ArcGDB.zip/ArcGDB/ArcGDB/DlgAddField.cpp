// DlgAddField.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgAddField.h"
//#include "afxdialogex.h"
#include <algorithm>
#include "SGUtils.h"
// DlgAddField ��ܤ��

IMPLEMENT_DYNAMIC(CDlgAddField, CDialog)

CDlgAddField::CDlgAddField(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_ADD_FIELD, pParent)
{
	m_strName = _T("");
	m_nType = 0;
	m_nLength = 0;
	m_nPrecision = 0;
	m_pvecUsedName = NULL;
	m_bOK = FALSE;

}

CDlgAddField::~CDlgAddField()
{
}

void CDlgAddField::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_FTYPE, m_oType);
	DDX_Text(pDX, IDC_FNAME, m_strName);
	DDX_Text(pDX, IDC_FALIAS, m_strAlias);
	DDX_CBIndex(pDX, IDC_FTYPE, m_nType);
	DDX_Text(pDX, IDC_FLENGTH, m_nLength);
	DDX_Text(pDX, IDC_FPRECISION, m_nPrecision);
}


BEGIN_MESSAGE_MAP(CDlgAddField, CDialog)
	ON_CBN_SELCHANGE(IDC_FTYPE, OnSelchangeType)
	ON_EN_CHANGE(IDC_FNAME, &CDlgAddField::OnEnChangeName)
END_MESSAGE_MAP()


// CDlgAddField �T���B�z�`��
BOOL CDlgAddField::OnInitDialog()
{
	CDialog::OnInitDialog();

	//if(theApp.GetXMLResAgent())
	//{
	//	//CString strTitle = (LPCTSTR)theApp.GetXMLResAgent()->LoadIDString(2500);
	//	//SetWindowTextW(strTitle);
	//	//theApp.GetXMLResAgent()->InitChildControlText(this->GetSafeHwnd());
	//	theApp.GetXMLResAgent()->InitializeWindow(this->GetSafeHwnd(), IDD_ADD_FIELD);
	//}

	m_oType.AddString(LoadXMLIDString(IDS_TYPESTRING));
	m_oType.AddString(LoadXMLIDString(IDS_TYPESHORT));
	m_oType.AddString(LoadXMLIDString(IDS_TYPELONG));
	m_oType.AddString(LoadXMLIDString(IDS_TYPEFLOAT));
	m_oType.AddString(LoadXMLIDString(IDS_TYPEDOUBLE));
	m_oType.AddString(LoadXMLIDString(IDS_TYPEDATE));
	m_oType.AddString(LoadXMLIDString(IDS_TYPELOGICAL));
	//m_oType.AddString(LoadXMLIDString(,L"Text"));
	//m_oType.AddString(LoadXMLIDString(,L"Short"));
	//m_oType.AddString(LoadXMLIDString(,L"Long"));
	//m_oType.AddString(LoadXMLIDString(,L"Float"));
	//m_oType.AddString(LoadXMLIDString(,L"Double"));
	//m_oType.AddString(LoadXMLIDString(,L"Date"));
	//m_oType.AddString(LoadXMLIDString(,L"Logical"));

	m_oType.SetCurSel(0);
	OnSelchangeType();
	GetDlgItem(IDOK)->EnableWindow(FALSE);
	return TRUE;
}

void CDlgAddField::OnSelchangeType()
{
	UpdateData(TRUE);
	BOOL bLen, bDec;
	if (m_nType == 0)
	{
		m_nLength = 50;
		bLen = TRUE;
		bDec = FALSE;
	}
	else if (m_nType == 1 || m_nType == 2)
	{
		m_nLength = (m_nType == 1) ? 4 : 9;
		bLen = TRUE;
		bDec = FALSE;
	}
	else if (m_nType == 5 || m_nType == 6)
	{
		m_nLength = 0;
		m_nPrecision = 0;
		bLen = FALSE;
		bDec = FALSE;
	}
	else if (m_nType == 3 || m_nType == 4)
	{
		m_nLength = (m_nType == 3) ? 13 : 19;
		m_nPrecision = 11;
		bLen = TRUE;
		bDec = TRUE;
	}

	GetDlgItem(IDC_FLENGTH)->EnableWindow(bLen);
	GetDlgItem(IDC_FPRECISION)->EnableWindow(bDec);
	UpdateData(FALSE);
}

void CDlgAddField::OnOK()
{
	m_bOK = FALSE;

	UpdateData(TRUE);
	m_strName.TrimLeft();
	m_strName.TrimRight();
	if (m_strName.IsEmpty())
		return;

	if (m_strName.GetLength() > 10)
	{
		AfxMessageBox(LoadXMLIDString(IDS_MSG1));
		GetDlgItem(IDC_FNAME)->SetFocus();
		return;
	}

	long alen = WideCharToMultiByte(0, 0, m_strName.GetString(), (int)wcslen(m_strName.GetString()), NULL, 0, NULL, NULL);
	if (alen > 10)
	{
		AfxMessageBox(LoadXMLIDString(IDS_MSG1));
		GetDlgItem(IDC_FNAME)->SetFocus();
		return;
	}
	//BYTE NameByte[22] = {0};
	//memcpy((void*)NameByte,(LPTSTR)(LPCTSTR)m_strName,22);
	//for(long i = 0 ; i < 22 ; i+=2)
	//{
	//	NameByte[i] == '0';
	//	NameByte[i+1] == '0';
	//}


	if (m_pvecUsedName != NULL)
	{
		std::vector<CString>::iterator pIter = std::find(m_pvecUsedName->begin(), m_pvecUsedName->end(), m_strName);
		if (pIter != m_pvecUsedName->end())
		{
			AfxMessageBox(LoadXMLIDString(IDS_MSG4));
			GetDlgItem(IDC_FNAME)->SetFocus();
			return;
		}
	}

	CDialog::OnOK();

	m_strName.Trim();
	if (m_strAlias.GetLength() == 0)
		m_strAlias = m_strName;

	m_bOK = TRUE;
}

void CDlgAddField::OnEnChangeName()
{
	// TODO:  �p�G�o�O RICHEDIT ����A����N���|
	// �ǰe���i���A���D�z�мg CSGDialog::OnInitDialog()
	// �禡�M�I�s CRichEditCtrl().SetEventMask()
	// ���㦳 ENM_CHANGE �X�� ORed �[�J�B�n�C
	CString strName;
	GetDlgItemText(IDC_FNAME, strName);
	strName.Trim();
	GetDlgItem(IDOK)->EnableWindow(!strName.IsEmpty());
	// TODO:  �b���[�J����i���B�z�`���{���X
}
