#pragma once

#include "resource.h"
#include "afxwin.h"
#include "afxcmn.h"

// CDlgTables ��ܤ��

class CDlgTables : public CDialog
{
	DECLARE_DYNAMIC(CDlgTables)

public:
	CDlgTables(SGCore::IDBWorkspacePtr pWS, SGCore::INameCollectionPtr pTables, CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTables();
	CStringArray* GetSelTables() { return &m_selTables; }

// ��ܤ�����
	enum { IDD = IDD_TABLES };

protected:
	SGCore::IDBWorkspacePtr m_pWS;
	SGCore::INameCollectionPtr m_pTables;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩
	CStringArray m_selTables;

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CListBox m_list;
	afx_msg void OnLbnSelchangeList1();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedBtnselall();
private:
	CListCtrl m_list2;
	CImageList m_imglist;
public:
	afx_msg void OnClose();
	afx_msg void OnBnClickedBtnprop();
};
