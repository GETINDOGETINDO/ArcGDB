// ExtButton.h : CExtButton ���ŧi

#pragma once

#include <vector>
#include "resource.h"       // �D�n�Ÿ�

#include "ArcGDB.h"
#include "BtnOpen.h"
#include "BtnCreate.h"
#include "BtnImport.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Windows CE ���x�W�����T�䴩��@����� COM ����A�Ҧp Windows Mobile ���x�S���]�t���㪺 DCOM �䴩�C�Щw�q _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA �ӱj�� ATL �䴩�إ߳�@����� COM ���󪺹�@�A�H�Τ��\�ϥΨ��@����� COM �����@�C�z�� rgs �ɤ���������ҫ��w�]�w�� 'Free'�A�]���o�O�D DCOM Windows CE ���x���ߤ@�䴩��������ҫ��C"
#endif



// CExtButton

class ATL_NO_VTABLE CExtButton :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CExtButton, &CLSID_ExtButton>,
	public IDispatchImpl<IExtButton, &IID_IExtButton, &LIBID_ArcGDBLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IDispatchImpl<SGCore::ICommand, &__uuidof(SGCore::ICommand), &SGCore::LIBID_SGCore, /* wMajor = */ 1>,
	public IDispatchImpl<SGCore::ICommandGroup, &__uuidof(SGCore::ICommandGroup), &SGCore::LIBID_SGCore, /* wMajor = */ 1>,
	public SGCore::IToolbarItem
{
	CString m_caption;
	SuperGIS3::IDualApplicationPtr m_pApp;
	std::vector<SGCore::ICommandPtr> m_vecCmd;

public:
	CExtButton()
	{
		m_caption = _T("File Geodatabase"); //Open a FileGDB (.gdb)

		SGCore::ICommandPtr pCmd;
		{
			CBtnOpen* pBtn1 = new CComObject<CBtnOpen>;
			pBtn1->AddRef();
			pCmd = pBtn1;
			m_vecCmd.push_back(pCmd);
			pBtn1->Release();
		}
		{
			CBtnCreate* pBtn1 = new CComObject<CBtnCreate>;
			pBtn1->AddRef();
			pCmd = pBtn1;
			m_vecCmd.push_back(pCmd);
			pBtn1->Release();
		}
		m_vecCmd.push_back(NULL);
		{
			CBtnImport* pBtn1 = new CComObject<CBtnImport>;
			pBtn1->AddRef();
			pCmd = pBtn1;
			m_vecCmd.push_back(pCmd);
			pBtn1->Release();
		}
	}

	DECLARE_REGISTRY_RESOURCEID(IDR_EXTBUTTON)


	BEGIN_COM_MAP(CExtButton)
		COM_INTERFACE_ENTRY(IExtButton)
		COM_INTERFACE_ENTRY2(IDispatch, SGCore::ICommand)
		COM_INTERFACE_ENTRY(SGCore::ICommand)
		COM_INTERFACE_ENTRY(SGCore::ICommandGroup)
		COM_INTERFACE_ENTRY(SGCore::IToolbarItem)
	END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:


	// ICommand Methods
public:
	STDMETHOD(get_Name)(BSTR * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_Caption)(BSTR * pVal)
	{
		*pVal = m_caption.AllocSysString();
		return S_OK;
	}
	STDMETHOD(get_ToolTip)(BSTR * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_Enabled)(VARIANT_BOOL * pVal)
	{
		*pVal = VARIANT_TRUE;
		return S_OK;
	}
	STDMETHOD(get_Checked)(VARIANT_BOOL * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_Image)(void * * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_HelpFile)(BSTR * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_HelpTopicID)(long * pVal)
	{
		return S_OK;
	}
	STDMETHOD(raw_OnCommand)(SGCore::ICommandTarget * Parent);

	// IToolbarItem
	STDMETHOD(raw_InitItem)(SGCore::ICommandTarget *);
	STDMETHOD(raw_ExitItem)(void) { m_pApp = NULL;  return S_OK; }

	// ICommandGroup
	STDMETHOD(get_ItemCount)(long * pVal)
	{
		*pVal = (long)m_vecCmd.size();
		return S_OK;
	}
	STDMETHOD(get_Item)(long index, SGCore::ICommand ** pCommand)
	{
		*pCommand = NULL;
		if (index < (long)m_vecCmd.size())
		{
			if (m_vecCmd[index] != NULL)
				m_vecCmd[index]->QueryInterface(SGCore::IID_ICommand, (void**)pCommand);
			return S_OK;
		}
		return S_FALSE;
	}

};

OBJECT_ENTRY_AUTO(__uuidof(ExtButton), CExtButton)
