// ExtBar.cpp : CExtBar ����@

#include "stdafx.h"
#include "ExtBar.h"


SGCore::ICommandTargetPtr g_parent = NULL;

// CExtBar

STDMETHODIMP CExtBar::raw_InitItem(SGCore::ICommandTarget * Parent)
{
	g_parent = Parent;
	return S_OK;
}

STDMETHODIMP CExtBar::raw_ExitItem()
{
	g_parent = NULL;
	return S_OK;
}
