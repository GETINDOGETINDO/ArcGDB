

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Tue Oct 01 10:50:17 2019
 */
/* Compiler settings for ArcGDB.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IExtBar,0xC7EE87CF,0x300B,0x43F5,0xB7,0x44,0xDD,0x4B,0x74,0x52,0xC9,0xDC);


MIDL_DEFINE_GUID(IID, IID_IExtButton,0x1783B87F,0xD9A0,0x4A94,0xB6,0x84,0x81,0x6F,0x63,0x5E,0x58,0x9B);


MIDL_DEFINE_GUID(IID, IID_IBtnOpen,0x2440051E,0x09FB,0x4E04,0x9D,0xBA,0xF6,0xB6,0x0D,0x4B,0xAC,0x8D);


MIDL_DEFINE_GUID(IID, IID_IBtnCreate,0xAABFCE8E,0xCC9B,0x4CFC,0xA2,0x92,0x45,0x62,0x6F,0xAE,0x61,0x1E);


MIDL_DEFINE_GUID(IID, IID_IBtnImport,0x9C3867CB,0xCB29,0x4D7F,0x83,0x99,0x1C,0x49,0xAC,0x7B,0x87,0x9E);


MIDL_DEFINE_GUID(IID, LIBID_ArcGDBLib,0x83D2FA95,0xDE57,0x422B,0x97,0x0F,0x63,0x4D,0x3D,0xAD,0x30,0xBD);


MIDL_DEFINE_GUID(CLSID, CLSID_ExtBar,0x19565592,0x19BA,0x427E,0xAF,0x31,0x51,0x23,0xA0,0xB1,0x76,0xCE);


MIDL_DEFINE_GUID(CLSID, CLSID_ExtButton,0x74F51DA6,0xC7C7,0x4556,0xAD,0x97,0xA6,0xCE,0xD6,0x40,0x8C,0x34);


MIDL_DEFINE_GUID(CLSID, CLSID_BtnOpen,0x42C5D0AE,0x708E,0x4998,0x88,0x73,0x4C,0x34,0x2C,0x6E,0xF0,0xC2);


MIDL_DEFINE_GUID(CLSID, CLSID_BtnCreate,0x5146E3BC,0x8FF6,0x4857,0xB5,0x6E,0x3B,0xEC,0x7F,0x4E,0x34,0x97);


MIDL_DEFINE_GUID(CLSID, CLSID_BtnImport,0x925EDFE4,0x0145,0x4817,0x9F,0x45,0xAD,0x6E,0xDC,0x2E,0x13,0xFA);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



