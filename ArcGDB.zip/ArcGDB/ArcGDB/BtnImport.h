// BtnImport.h : CBtnImport ���ŧi

#pragma once
#include "resource.h"       // �D�n�Ÿ�



#include "ArcGDB.h"
#include "..\SuperGIS3_category.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Windows CE ���x�W�����T�䴩��@����� COM ����A�Ҧp Windows Mobile ���x�S���]�t���㪺 DCOM �䴩�C�Щw�q _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA �ӱj�� ATL �䴩�إ߳�@����� COM ���󪺹�@�A�H�Τ��\�ϥΨ��@����� COM �����@�C�z�� rgs �ɤ���������ҫ��w�]�w�� 'Free'�A�]���o�O�D DCOM Windows CE ���x���ߤ@�䴩��������ҫ��C"
#endif

using namespace ATL;


// CBtnImport

class ATL_NO_VTABLE CBtnImport :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CBtnImport, &CLSID_BtnImport>,
	public IDispatchImpl<IBtnImport, &IID_IBtnImport, &LIBID_ArcGDBLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IDispatchImpl<SGCore::ICommand, &__uuidof(SGCore::ICommand), &SGCore::LIBID_SGCore, /* wMajor = */ 1>,
	public SGCore::IToolbarItem
{
	CString m_caption;
	SuperGIS3::IDualApplicationPtr m_pApp;
	CString m_curPath;

public:
	CBtnImport()
	{
		m_caption = _T("GDB List");  // _T("Import Feature Class To GDB...");
	}

DECLARE_REGISTRY_RESOURCEID(IDR_BTNIMPORT)


BEGIN_COM_MAP(CBtnImport)
	COM_INTERFACE_ENTRY(IBtnImport)
	COM_INTERFACE_ENTRY2(IDispatch, SGCore::ICommand)
	COM_INTERFACE_ENTRY(SGCore::ICommand)
	COM_INTERFACE_ENTRY(SGCore::IToolbarItem)

END_COM_MAP()



	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:

	// ICommand Methods
public:
	STDMETHOD(get_Name)(BSTR * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_Caption)(BSTR * pVal)
	{
		*pVal = m_caption.AllocSysString();
		return S_OK;
	}
	STDMETHOD(get_ToolTip)(BSTR * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_Enabled)(VARIANT_BOOL * pVal)
	{
		*pVal = VARIANT_TRUE;
		return S_OK;
	}
	STDMETHOD(get_Checked)(VARIANT_BOOL * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_Image)(void * * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_HelpFile)(BSTR * pVal)
	{
		return S_OK;
	}
	STDMETHOD(get_HelpTopicID)(long * pVal)
	{
		return S_OK;
	}
	STDMETHOD(raw_OnCommand)(SGCore::ICommandTarget * Parent);

	// IToolbarItem
	STDMETHOD(raw_InitItem)(SGCore::ICommandTarget *);
	STDMETHOD(raw_ExitItem)(void);

};

OBJECT_ENTRY_AUTO(__uuidof(BtnImport), CBtnImport)
