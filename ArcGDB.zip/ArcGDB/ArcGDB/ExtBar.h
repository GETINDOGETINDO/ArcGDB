// ExtBar.h : CExtBar ���ŧi

#pragma once
#include "resource.h"       // �D�n�Ÿ�

#include "ArcGDB.h"
#include "..\SuperGIS3_category.h"
#include <vector>
#include "ExtButton.h"
#include "BtnOpen.h"
#include "BtnCreate.h"
#include "BtnImport.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Windows CE ���x�W�����T�䴩��@����� COM ����A�Ҧp Windows Mobile ���x�S���]�t���㪺 DCOM �䴩�C�Щw�q _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA �ӱj�� ATL �䴩�إ߳�@����� COM ���󪺹�@�A�H�Τ��\�ϥΨ��@����� COM �����@�C�z�� rgs �ɤ���������ҫ��w�]�w�� 'Free'�A�]���o�O�D DCOM Windows CE ���x���ߤ@�䴩��������ҫ��C"
#endif



// CExtBar

class ATL_NO_VTABLE CExtBar :
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CExtBar, &CLSID_ExtBar>,
	public IDispatchImpl<IExtBar, &IID_IExtBar, &LIBID_ArcGDBLib, /*wMajor =*/ 1, /*wMinor =*/ 0>,
	public IDispatchImpl<SGCore::ICommand, &__uuidof(SGCore::ICommand), &SGCore::LIBID_SGCore, /* wMajor = */ 1>,
	public IDispatchImpl<SGCore::ICommandGroup, &__uuidof(SGCore::ICommandGroup), &SGCore::LIBID_SGCore, /* wMajor = */ 1>,
	public SGCore::IToolbarItem
{
	CString m_caption;
	std::vector<SGCore::ICommandPtr> m_vecCmd;

public:
	CExtBar()
	{
		m_caption = _T("Arc GDB");

		SGCore::ICommandPtr pCmd;
		CExtButton* pBtn = new CComObject<CExtButton>;
		pBtn->AddRef();
		pCmd = pBtn;
		VARIANT_BOOL b;
		pCmd->get_Enabled(&b);
		m_vecCmd.push_back(pCmd);
		pBtn->Release();
	}

	DECLARE_REGISTRY_RESOURCEID(IDR_EXTBAR)


	BEGIN_COM_MAP(CExtBar)
		COM_INTERFACE_ENTRY(IExtBar)
		COM_INTERFACE_ENTRY2(IDispatch, SGCore::ICommand)
		COM_INTERFACE_ENTRY(SGCore::ICommand)
		COM_INTERFACE_ENTRY(SGCore::ICommandGroup)
		COM_INTERFACE_ENTRY(SGCore::IToolbarItem)
	END_COM_MAP()

	BEGIN_CATEGORY_MAP(CExtBar)
		IMPLEMENTED_CATEGORY(SuperGISDesktop_ToolBarCategory)
	END_CATEGORY_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:


	// ICommand Methods
public:
	STDMETHOD(get_Name)(BSTR * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(get_Caption)(BSTR * pVal)
	{
		*pVal = m_caption.AllocSysString();
		return S_OK;
	}
	STDMETHOD(get_ToolTip)(BSTR * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(get_Enabled)(VARIANT_BOOL * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(get_Checked)(VARIANT_BOOL * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(get_Image)(void * * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(get_HelpFile)(BSTR * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(get_HelpTopicID)(long * pVal)
	{
		return E_NOTIMPL;
	}
	STDMETHOD(raw_OnCommand)(SGCore::ICommandTarget * Parent)
	{
		return E_NOTIMPL;
	}

	// ICommandGroup Methods
public:
	STDMETHOD(get_ItemCount)(long * pVal)
	{
		*pVal = (long)m_vecCmd.size();
		return S_OK;
	}
	STDMETHOD(get_Item)(long index, SGCore::ICommand ** pCommand)
	{
		*pCommand = NULL;
		if (index < (long)m_vecCmd.size())
		{
			if (m_vecCmd[index] != NULL)
				m_vecCmd[index]->QueryInterface(SGCore::IID_ICommand, (void**)pCommand);
			return S_OK;
		}
		return S_FALSE;
	}

	// IToolbarItem Methods
public:
	STDMETHOD(raw_InitItem)(SGCore::ICommandTarget * Parent);
	STDMETHOD(raw_ExitItem)();
};

OBJECT_ENTRY_AUTO(__uuidof(ExtBar), CExtBar)
