// DlgImport.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "SGUtils.h"
#include "DlgImport.h"
//#include "afxdialogex.h"
#include "DirDialog.h"

extern SGCore::ICommandTargetPtr g_parent;
extern CString s_createGDB;
// CDlgImport ��ܤ��

IMPLEMENT_DYNAMIC(CDlgImport, CDialog)

CDlgImport::CDlgImport(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_IMPORT, pParent)
	, m_outputGDB(_T(""))
	, m_pLays(NULL)
	, m_dataset(_T(""))
{
	m_bLockOutput = false;
}

CDlgImport::~CDlgImport()
{
}

void CDlgImport::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_PATH, m_outputGDB);
	DDX_Control(pDX, IDC_CBOLAY, m_cboLay);
	DDX_Control(pDX, IDC_LIST, m_lst);
	DDX_Text(pDX, IDC_DATASET, m_dataset);
}


BEGIN_MESSAGE_MAP(CDlgImport, CDialog)
	ON_BN_CLICKED(IDC_BTNOPEN, &CDlgImport::OnBnClickedBtnopen)
	ON_BN_CLICKED(IDC_BTNADD, &CDlgImport::OnBnClickedBtnadd)
	ON_BN_CLICKED(IDC_BTNDEL, &CDlgImport::OnBnClickedBtndel)
	ON_BN_CLICKED(IDC_BTNPATH, &CDlgImport::OnBnClickedBtnpath)
	ON_BN_CLICKED(IDOK, &CDlgImport::OnBnClickedOk)
	ON_CBN_SELCHANGE(IDC_CBOLAY, &CDlgImport::OnCbnSelchangeCbolay)
END_MESSAGE_MAP()


// CDlgImport �T���B�z�`��


void CDlgImport::OnBnClickedBtnopen()
{
	SGDataSelect::IDataSelector2Ptr pSel;
	//if (m_pSel == NULL)
	{
		
		if (pSel.CreateInstance(SGDataSelect::CLSID_DataSelector2) != S_OK)
			return ;

		pSel->RemoveAllFilter();
		SGDataSelect::IDataFilter2Ptr pDF(SGDataSelect::CLSID_DataFilter2);
		pDF->SetFilterType((SGDataSelect::SGODataFilterType)7); 
		pSel->raw_AddFilter(pDF);
		pSel->put_MultiSelection(TRUE);
	}
	long Result = IDCANCEL;
	if (pSel->raw_Show(&Result) == S_OK && (Result == IDOK))
	{
		long Cnt = 0;
		pSel->get_SelectedCount(&Cnt);
		if (Cnt > 0)
		{
			m_cboLay.SetWindowText(L"");
			BSTR bz = NULL;
			for (long k = 0; k < Cnt; k++)
			{
				if (pSel->get_SelectedFile(k, &bz) == S_OK)
				{
					IUnknownPtr pUnk;
					if (pSel->get_SelectedObject(k, &pUnk) == S_OK)
					{
						CString buf = bz;
						CString buf2;
						bool bHave = false;
						for (int i = 0; i < m_lst.GetCount(); i++)
						{
							m_lst.GetText(i, buf2);
							if (buf.CompareNoCase(buf2) == 0)
							{
//#ifdef _DEBUG
//								::SysFreeString(bz);
//								buf2.Format(L"Had add(%d)!\r\n%s\r\n%s", i, buf2, buf);
//								MessageBox(buf2);
//#else
//								MessageBox(L"Had add!");
//#endif
								bHave = true;
								break;
							}
						}
						if (!bHave)
						{
							long ki = m_openLays.Add(pUnk) + 1;
							long ai = m_lst.AddString(buf);
							m_lst.SetItemData(ai, -ki);
						}
					}
				}
				::SysFreeString(bz);
			}
		}
	}
}


void CDlgImport::OnBnClickedBtnadd()
{
	UpdateData();
	CString buf;
	m_cboLay.GetWindowText(buf);
	buf = buf.Trim();
	if (!buf.IsEmpty())
	{
		CString buf2;
		for (int i = 0; i < m_lst.GetCount(); i++)
		{
			m_lst.GetText(i, buf2);
			if (buf.CompareNoCase(buf2) == 0)
			{
				MessageBox(L"Had add!");
				return;
			}
		}
		SGCore::IFeatureClassPtr pFC=SGOpenFeatureClass(buf, NULL);
		if (pFC == NULL)
		{
			MessageBox(L"Not a feature file");
			return;
		}
		SGCore::IFeatureLayerPtr pFL(SGMap::CLSID_FeatureLayer);
		pFL->putref_FeatureClass(pFC);

		long ki = m_openLays.Add(pFL) + 1;
		long ai = m_lst.AddString(buf);
		m_lst.SetItemData(ai, -ki);
	}
}


void CDlgImport::OnBnClickedBtndel()
{
	if (m_lst.GetSelCount())
	{
		for (int i = 0; i<m_lst.GetCount(); i++)
			if (m_lst.GetSel(i))
				m_lst.DeleteString(i--);
	}
}


void CDlgImport::OnBnClickedBtnpath()
{
	UpdateData();
	CDirDialog dd;
#ifdef _DEBUG
	if (m_outputGDB.IsEmpty())
		m_outputGDB = L"f:\\test\\gdb";
#endif

	dd.m_strSelDir = m_outputGDB;
	if (!dd.DoBrowse(AfxGetMainWnd()))
		return;
	SGFileGDB::IGDBWorkspacePtr pGWS(SGFileGDB::CLSID_GDBWorkspace);
	if (!pGWS->Open(_bstr_t(dd.m_strPath)))
		MessageBox(_T("Not a valid FileGDB Folder!"));
	else
		m_outputGDB = dd.m_strPath;

	UpdateData(FALSE);
}


void CDlgImport::OnBnClickedOk()
{
	UpdateData();
	int n = m_lst.GetCount();
	if (n <= 0)
	{
		MessageBox(_T("Please Input Features!"));
		return;
	}
	m_outputGDB = m_outputGDB.Trim();
	if (m_outputGDB.IsEmpty())
	{
		MessageBox(_T("Please Input GDB!"));
		return;
	}
	m_dataset = m_dataset.Trim();
	if (!m_dataset.IsEmpty() && m_dataset.FindOneOf(L"\\/") >= 0)
	{
		MessageBox(_T("Dataset Name input error!"));
		return;
	}

	SGFileGDB::IGDBWorkspacePtr pGWS;
	if (m_bLockOutput)
	{
		pGWS = g_gdbList.GetGDB(m_outputGDB, FALSE);
		if (pGWS==NULL)
		{
			MessageBox(_T("No FileGDB!"));
			return;
		}
	}
	else
	{
		pGWS.CreateInstance(SGFileGDB::CLSID_GDBWorkspace);
		if (!pGWS->Open(_bstr_t(m_outputGDB)))
		{
			MessageBox(_T("Not a valid FileGDB Folder!"));
			return;
		}
	}
	CWaitCursor cur;
	this->EnableWindow(FALSE);
	SGCore::IDBWorkspacePtr pWS = pGWS;
	SGCore::IDBWorkspace4Ptr pWS4 = pGWS;

	SGCore::IFeatureLayerPtr pFlay;
	SGCore::IFeatureClassPtr pFeatureClass;
	SGSFCOMS::ISpatialReferencePtr pSR;
	IUnknownPtr pUnk;
	SGCore::IFeatureCursorPtr pFCur;
	SGCore::IFeaturePtr pFeature;

	int okn = 0;
	CString lbuf;
	CString buf;
	for (int i = 0; i < n; i++)
	{
		long id = m_lst.GetItemData(i);
		pFlay = NULL;
		if (id > 0)
		{
			id--;
			pFlay =m_pLays->GetAt(id);
		}
		else if (id < 0)
		{
			id = -(id + 1);
			pFlay = m_openLays[id];
		}
		if (pFlay)
		{
			CString layername= pFlay->Name;
			pFeatureClass = pFlay->GetFeatureClass();

			SGCore::IGeoDatasetPtr pGD = pFeatureClass;
			pGD->get_SpatialReference(&pSR);

			SGCore::IFieldsPtr pSrcFields;
			pFeatureClass->get_Fields(&pSrcFields);

			long nFields = 0;
			pSrcFields->get_FieldCount(&nFields);

			SGCore::IFieldsEditPtr pFields(SGDataAccess::CLSID_Fields);
			SetupGDBFields(pFields, pSrcFields, FALSE);

			if (!m_dataset.IsEmpty())
				layername = m_dataset+L"\\" + layername;

			long ftype = pFeatureClass->FeatureType;
			//��(z+1000),m(+2000)

			SGCore::IFeatureClassPtr pNewFeatureClass = NULL;
			HRESULT hr;
			if (pWS4)
				hr = pWS4->raw_CreateTable2(_bstr_t(layername), _T("SHAPE"), (SGCore::SGOGeometryType)ftype , pFields, pSR, &pNewFeatureClass);
			else
				hr = pWS->raw_CreateTable(_bstr_t(layername), _T("SHAPE"), (SGCore::SGOGeometryType)ftype, pFields, &pNewFeatureClass);

			if (pNewFeatureClass)
			{
				pFCur = pFeatureClass->Search(NULL);
				CopyRecords(pNewFeatureClass, pSrcFields, pFCur, FALSE, TRUE);
				okn++;
			}
			else
			{
				buf.Format(L"%s(err=%ld)\r\n", layername, hr);
				lbuf += buf;
			}
		}
	}
	this->EnableWindow();
	if (lbuf.IsEmpty())
	{
		MessageBox(L"Import OK.");
		CDialog::OnOK();
	}
	else
	{
		lbuf = L"Import following features err:\r\n" + lbuf;
		MessageBox(lbuf);
		if (m_bLockOutput && okn>0)
			CDialog::OnOK();
	}
}


BOOL CDlgImport::OnInitDialog()
{
	CDialog::OnInitDialog();
	((CButton*)(this->GetDlgItem(IDC_BTNOPEN)))->SetIcon(AfxGetApp()->LoadIcon(IDI_BROWSE));
	((CButton*)(this->GetDlgItem(IDC_BTNADD)))->SetIcon(AfxGetApp()->LoadIcon(IDI_ADD));
	((CButton*)(this->GetDlgItem(IDC_BTNDEL)))->SetIcon(AfxGetApp()->LoadIcon(IDI_DEL));
	if (m_outputGDB.IsEmpty())
		m_outputGDB = s_createGDB;
	else
	{
		m_bLockOutput = true;
		GetDlgItem(IDC_BTNPATH)->EnableWindow(FALSE);
		GetDlgItem(IDC_PATH)->EnableWindow(FALSE);
		((CEdit*)GetDlgItem(IDC_PATH))->SetReadOnly();
		//m_dataset = L"";
	}
	m_cboLay.AddString(L"");
	if (m_pLays == NULL && g_parent)
	{
		m_Lays.RemoveAll();
		RetrieveLayerCollection(g_parent->GetMap(), &m_Lays, TRUE);
		m_pLays = &m_Lays;
	}

	{
		for (long i = 0; i < m_pLays->GetCount(); i++)
		{
			SGCore::IFeatureLayerPtr pLay = m_pLays->GetAt(i);
			CString buf=pLay->GetTitle();
			int ai=m_cboLay.AddString(buf);
			m_cboLay.SetItemData(ai, i+1);
		}
	}
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}


void CDlgImport::OnCbnSelchangeCbolay()
{
	UpdateData();
	int seli = m_cboLay.GetCurSel();
	TRACE("seli=%d\n", seli);
	if (seli > 0)
	{
		long ki=m_cboLay.GetItemData(seli);
		for (int i = 0; i < m_lst.GetCount(); i++)
		{
			if (ki == m_lst.GetItemData(i))
			{
				MessageBox(L"Had add!");
				m_cboLay.SetWindowText(L"");
				m_cboLay.SetCurSel(-1);
				return;
			}
		}
		CString buf;
		m_cboLay.GetLBText(seli, buf);
		long ai = m_lst.AddString(buf);
		m_lst.SetItemData(ai, ki);
		m_cboLay.SetWindowText(L"");
		m_cboLay.SetCurSel(-1);
	}
}
