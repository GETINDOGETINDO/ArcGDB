#pragma once

#include "afxwin.h"
#include "afxcmn.h"

// CDlgProp ��ܤ��

class CDlgProp : public CDialog
{
	DECLARE_DYNAMIC(CDlgProp)

public:
	CDlgProp(SGCore::IDBWorkspacePtr pWS, SGCore::INameCollectionPtr pNames, CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgProp();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PROP };
#endif

protected:
	SGCore::IDBWorkspacePtr m_pWS;
	SGCore::INameCollectionPtr m_pNames;
	CStringArray m_defs;

	void ListItems(int seli);

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();

private:
	//https://docs.microsoft.com/zh-tw/cpp/mfc/reference/cheaderctrl-class?view=vs-2019
	//CMFCListCtrl, CMFCHeaderCtrl(override OnFillBackground)
	//::DrawFrameControl(lpDrawItemStruct->hDC, &lpDrawItemStruct->rcItem, DFC_BUTTON, DFCS_BUTTONPUSH);
	CListCtrl m_list2;
	CListCtrl m_list3;
	CListCtrl m_list4;
public:
	afx_msg void OnLvnItemchangedList2(NMHDR *pNMHDR, LRESULT *pResult);
};
