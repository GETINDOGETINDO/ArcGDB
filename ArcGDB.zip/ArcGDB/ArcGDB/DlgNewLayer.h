#pragma once

#include <vector>
#include <map>

// CDlgNewLayer ��ܤ��

class CDlgNewLayer : public CDialog
{
	DECLARE_DYNAMIC(CDlgNewLayer)

public:
	CDlgNewLayer(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgNewLayer();

	std::map<CString, CString> m_mapNameAlias;
	int		m_nType;
	CString m_layername;
	SGFileGDB::IGDBWorkspacePtr m_pGdb;
	CString m_dataset;


// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_NEWLAYER };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩
	SGSFCOMS::ISpatialReferencePtr m_pSptRef;
	std::vector<int> m_Type;
	std::vector<CString> m_Alias;
	static CString m_strDefPath;
	CListCtrl m_list;

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedSelect();
	afx_msg void OnBnClickedOk();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedBtnadd();
	afx_msg void OnBnClickedBtnemove();
	afx_msg void OnTimer(UINT_PTR nIDEvent);

};
