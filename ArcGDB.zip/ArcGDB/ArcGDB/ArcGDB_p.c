

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Tue Oct 01 10:50:17 2019
 */
/* Compiler settings for ArcGDB.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#if !defined(_M_IA64) && !defined(_M_AMD64) && !defined(_ARM_)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extern to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma warning( disable: 4024 )  /* array to pointer mapping*/
#pragma warning( disable: 4152 )  /* function/data pointer conversion in expression */
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */

#pragma optimize("", off ) 

#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 440
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif /* __RPCPROXY_H_VERSION__ */


#include "ArcGDB.h"

#define TYPE_FORMAT_STRING_SIZE   3                                 
#define PROC_FORMAT_STRING_SIZE   1                                 
#define EXPR_FORMAT_STRING_SIZE   1                                 
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   0            

typedef struct _ArcGDB_MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } ArcGDB_MIDL_TYPE_FORMAT_STRING;

typedef struct _ArcGDB_MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } ArcGDB_MIDL_PROC_FORMAT_STRING;

typedef struct _ArcGDB_MIDL_EXPR_FORMAT_STRING
    {
    long          Pad;
    unsigned char  Format[ EXPR_FORMAT_STRING_SIZE ];
    } ArcGDB_MIDL_EXPR_FORMAT_STRING;


static const RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const ArcGDB_MIDL_TYPE_FORMAT_STRING ArcGDB__MIDL_TypeFormatString;
extern const ArcGDB_MIDL_PROC_FORMAT_STRING ArcGDB__MIDL_ProcFormatString;
extern const ArcGDB_MIDL_EXPR_FORMAT_STRING ArcGDB__MIDL_ExprFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IExtBar_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IExtBar_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IExtButton_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IExtButton_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IBtnOpen_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IBtnOpen_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IBtnCreate_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IBtnCreate_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IBtnImport_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IBtnImport_ProxyInfo;



#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will fail with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const ArcGDB_MIDL_PROC_FORMAT_STRING ArcGDB__MIDL_ProcFormatString =
    {
        0,
        {

			0x0
        }
    };

static const ArcGDB_MIDL_TYPE_FORMAT_STRING ArcGDB__MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */

			0x0
        }
    };


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IExtBar, ver. 0.0,
   GUID={0xC7EE87CF,0x300B,0x43F5,{0xB7,0x44,0xDD,0x4B,0x74,0x52,0xC9,0xDC}} */

#pragma code_seg(".orpc")
static const unsigned short IExtBar_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IExtBar_ProxyInfo =
    {
    &Object_StubDesc,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IExtBar_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IExtBar_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IExtBar_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IExtBarProxyVtbl = 
{
    0,
    &IID_IExtBar,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IDispatch::GetTypeInfoCount */ ,
    0 /* IDispatch::GetTypeInfo */ ,
    0 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IExtBar_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IExtBarStubVtbl =
{
    &IID_IExtBar,
    &IExtBar_ServerInfo,
    7,
    &IExtBar_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IExtButton, ver. 0.0,
   GUID={0x1783B87F,0xD9A0,0x4A94,{0xB6,0x84,0x81,0x6F,0x63,0x5E,0x58,0x9B}} */

#pragma code_seg(".orpc")
static const unsigned short IExtButton_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IExtButton_ProxyInfo =
    {
    &Object_StubDesc,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IExtButton_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IExtButton_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IExtButton_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IExtButtonProxyVtbl = 
{
    0,
    &IID_IExtButton,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IDispatch::GetTypeInfoCount */ ,
    0 /* IDispatch::GetTypeInfo */ ,
    0 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IExtButton_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IExtButtonStubVtbl =
{
    &IID_IExtButton,
    &IExtButton_ServerInfo,
    7,
    &IExtButton_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IBtnOpen, ver. 0.0,
   GUID={0x2440051E,0x09FB,0x4E04,{0x9D,0xBA,0xF6,0xB6,0x0D,0x4B,0xAC,0x8D}} */

#pragma code_seg(".orpc")
static const unsigned short IBtnOpen_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IBtnOpen_ProxyInfo =
    {
    &Object_StubDesc,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IBtnOpen_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IBtnOpen_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IBtnOpen_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IBtnOpenProxyVtbl = 
{
    0,
    &IID_IBtnOpen,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IDispatch::GetTypeInfoCount */ ,
    0 /* IDispatch::GetTypeInfo */ ,
    0 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IBtnOpen_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IBtnOpenStubVtbl =
{
    &IID_IBtnOpen,
    &IBtnOpen_ServerInfo,
    7,
    &IBtnOpen_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IBtnCreate, ver. 0.0,
   GUID={0xAABFCE8E,0xCC9B,0x4CFC,{0xA2,0x92,0x45,0x62,0x6F,0xAE,0x61,0x1E}} */

#pragma code_seg(".orpc")
static const unsigned short IBtnCreate_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IBtnCreate_ProxyInfo =
    {
    &Object_StubDesc,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IBtnCreate_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IBtnCreate_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IBtnCreate_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IBtnCreateProxyVtbl = 
{
    0,
    &IID_IBtnCreate,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IDispatch::GetTypeInfoCount */ ,
    0 /* IDispatch::GetTypeInfo */ ,
    0 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IBtnCreate_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IBtnCreateStubVtbl =
{
    &IID_IBtnCreate,
    &IBtnCreate_ServerInfo,
    7,
    &IBtnCreate_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IBtnImport, ver. 0.0,
   GUID={0x9C3867CB,0xCB29,0x4D7F,{0x83,0x99,0x1C,0x49,0xAC,0x7B,0x87,0x9E}} */

#pragma code_seg(".orpc")
static const unsigned short IBtnImport_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0
    };

static const MIDL_STUBLESS_PROXY_INFO IBtnImport_ProxyInfo =
    {
    &Object_StubDesc,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IBtnImport_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IBtnImport_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    ArcGDB__MIDL_ProcFormatString.Format,
    &IBtnImport_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(7) _IBtnImportProxyVtbl = 
{
    0,
    &IID_IBtnImport,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* IDispatch::GetTypeInfoCount */ ,
    0 /* IDispatch::GetTypeInfo */ ,
    0 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */
};


static const PRPC_STUB_FUNCTION IBtnImport_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION
};

CInterfaceStubVtbl _IBtnImportStubVtbl =
{
    &IID_IBtnImport,
    &IBtnImport_ServerInfo,
    7,
    &IBtnImport_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    ArcGDB__MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x800025b, /* MIDL Version 8.0.603 */
    0,
    0,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0
    };

const CInterfaceProxyVtbl * const _ArcGDB_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_IBtnOpenProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IExtButtonProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IBtnCreateProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IBtnImportProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IExtBarProxyVtbl,
    0
};

const CInterfaceStubVtbl * const _ArcGDB_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_IBtnOpenStubVtbl,
    ( CInterfaceStubVtbl *) &_IExtButtonStubVtbl,
    ( CInterfaceStubVtbl *) &_IBtnCreateStubVtbl,
    ( CInterfaceStubVtbl *) &_IBtnImportStubVtbl,
    ( CInterfaceStubVtbl *) &_IExtBarStubVtbl,
    0
};

PCInterfaceName const _ArcGDB_InterfaceNamesList[] = 
{
    "IBtnOpen",
    "IExtButton",
    "IBtnCreate",
    "IBtnImport",
    "IExtBar",
    0
};

const IID *  const _ArcGDB_BaseIIDList[] = 
{
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    0
};


#define _ArcGDB_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _ArcGDB, pIID, n)

int __stdcall _ArcGDB_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _ArcGDB, 5, 4 )
    IID_BS_LOOKUP_NEXT_TEST( _ArcGDB, 2 )
    IID_BS_LOOKUP_NEXT_TEST( _ArcGDB, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _ArcGDB, 5, *pIndex )
    
}

const ExtendedProxyFileInfo ArcGDB_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _ArcGDB_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _ArcGDB_StubVtblList,
    (const PCInterfaceName * ) & _ArcGDB_InterfaceNamesList,
    (const IID ** ) & _ArcGDB_BaseIIDList,
    & _ArcGDB_IID_Lookup, 
    5,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#pragma optimize("", on )
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* !defined(_M_IA64) && !defined(_M_AMD64) && !defined(_ARM_) */

