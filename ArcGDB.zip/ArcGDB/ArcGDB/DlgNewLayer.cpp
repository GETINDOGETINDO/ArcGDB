// DlgNewLayer.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgNewLayer.h"
//#include "afxdialogex.h"
#include <algorithm>
#include "DlgAddField.h"
#include "SGUtils.h"

CString CDlgNewLayer::m_strDefPath = L"";
// CDlgNewLayer ��ܤ��

IMPLEMENT_DYNAMIC(CDlgNewLayer, CDialog)

CDlgNewLayer::CDlgNewLayer(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_NEWLAYER, pParent)
	, m_layername(_T(""))
{
	m_nType = 0;
}

CDlgNewLayer::~CDlgNewLayer()
{
}

void CDlgNewLayer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBIndex(pDX, IDC_TYPE, m_nType);
	DDX_Control(pDX, IDC_LISTFIELD, m_list);
	DDX_Text(pDX, IDC_NAME2, m_layername);
}


BEGIN_MESSAGE_MAP(CDlgNewLayer, CDialog)
	ON_BN_CLICKED(IDC_SELECT_COORD, &CDlgNewLayer::OnBnClickedSelect)
	ON_BN_CLICKED(IDOK, &CDlgNewLayer::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BTNADD, &CDlgNewLayer::OnBnClickedBtnadd)
	ON_BN_CLICKED(IDC_BTNREMOVE, &CDlgNewLayer::OnBnClickedBtnemove)
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CDlgNewLayer �T���B�z�`��
BOOL CDlgNewLayer::OnInitDialog()
{
	CDialog::OnInitDialog();

	//if(theApp.GetXMLResAgent())
	//{
	//	theApp.GetXMLResAgent()->InitializeWindow(this->GetSafeHwnd(), IDD_NEW_LAYER);
	//}
	CComboBox* pCombo = (CComboBox*)GetDlgItem(IDC_TYPE);
	pCombo->ResetContent();
	pCombo->AddString( L"Point");
	pCombo->AddString( L"Line");
	pCombo->AddString( L"Polygon");
	pCombo->SetCurSel(0);

	// list��header
	DWORD ExStyle = m_list.GetExtendedStyle();
	m_list.SetExtendedStyle(ExStyle | LVS_EX_FULLROWSELECT);

	m_list.InsertColumn(0, LoadXMLIDString(IDS_NAME), 0, 80);
	m_list.InsertColumn(1, LoadXMLIDString(IDS_TYPE), 0, 45);
	m_list.InsertColumn(2, LoadXMLIDString(IDS_LENGTH), 0, 45);
	m_list.InsertColumn(3, LoadXMLIDString(IDS_PRECISION), 0, 45);

	int nRow = m_list.InsertItem(m_list.GetItemCount(), L"Id");
	m_list.SetItemText(nRow, 1, L"Long");
	m_list.SetItemText(nRow, 2, L"9");
	m_list.SetItemText(nRow, 3, L"0");

	m_list.SetItemData(nRow, 2);
	m_Type.push_back(2);

	m_Alias.push_back(L"Id");
	if (!m_dataset.IsEmpty())
	{
		GetDlgItem(IDC_SELECT_COORD)->EnableWindow(FALSE);
		if (m_pSptRef)
			GetDlgItem(IDC_COORD_NAME)->SetWindowText(m_pSptRef->Name);
	}

	SetTimer(1122, 500, NULL); //�ΨӧY�ɧ�sx��enable disable

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}


void CDlgNewLayer::OnBnClickedSelect()
{
	SGUserInterface::ICSSelectorPtr pCS(SGUserInterface::CLSID_CSSelector);
	_bstr_t bstr = pCS->Show();
	if (bstr.length() == 0)
		return;
	m_pSptRef = pCS->SpatialReference;
	GetDlgItem(IDC_COORD_NAME)->SetWindowText(m_pSptRef->Name);
}

void CDlgNewLayer::OnBnClickedOk()
{
	UpdateData();

	long ftype= m_nType+1;
	//CString name, filter;
	bool bZ = (((CButton*)GetDlgItem(IDC_ADDZ))->GetCheck()!=0);
	if (bZ)
		ftype += 1000;

	// �ǳ����
	SGCore::IFieldsPtr pFields;
	pFields.CreateInstance(SGDataAccess::CLSID_Fields);
	for (int i = 0; i < m_list.GetItemCount(); i++)
	{
		SGCore::IFieldPtr pField;
		pField.CreateInstance(SGDataAccess::CLSID_Field);
		pField->Name = (_bstr_t)m_list.GetItemText(i, 0);
		CString strNum = m_list.GetItemText(i, 2);
		pField->put_Length(_ttol(strNum));
		strNum = m_list.GetItemText(i, 3);
		long nDec = _ttol(strNum);
		SGCore::IField2Ptr pField2 = pField;
		if (nDec != 0 && pField2)
			pField2->put_Precision(nDec);
		DWORD_PTR ftype = m_list.GetItemData(i);
		switch (ftype)
		{
		case 0:
			pField->put_Type(SGCore::SGO_FT_BSTR);
			break;
		case 1:
			pField->put_Type(SGCore::SGO_FT_SmallInt);
			break;
		case 2:
			pField->put_Type(SGCore::SGO_FT_Integer);
			break;
		case 3:
			pField->put_Type(SGCore::SGO_FT_Single);
			break;
		case 4:
			pField->put_Type(SGCore::SGO_FT_Double);
			break;
		case 5:
			pField->put_Type(SGCore::SGO_FT_Date);
			break;
		case 6:
			pField->put_Type(SGCore::SGO_FT_Boolean);
			break;
		default:
			pField->put_Type(SGCore::SGO_FT_BSTR);
			break;
		}
		//pField->put_Length(_ttol(strNum));
		//pField->put_Name(_T("ID"));
		//pField->put_Length(9);
		//pField->put_Type(SGCore::SGO_FT_Decimal);
		SGCore::IFieldsEditPtr pEdit = pFields;
		pEdit->AddField(pField);
		//�B�z�O�W
		CString strName = m_list.GetItemText(i, 0);
		m_mapNameAlias.insert(std::pair<CString, CString>(strName, m_Alias[i]));
	}

	//m_layertitle = m_layertitle.Mid(pos2 + 1, pos1 - pos2 - 1);
	if (m_pGdb)
	{
		CString lbuf;
		if (m_dataset.IsEmpty())
			lbuf = m_layername;
		else
			lbuf = m_dataset+L"\\"+m_layername;

		SGCore::IDBWorkspace4Ptr pWS4 = m_pGdb;
		SGCore::IFeatureClassPtr pNewFeatureClass = NULL;
		HRESULT hr = pWS4->raw_CreateTable2(_bstr_t(lbuf), _T("SHAPE"), (SGCore::SGOGeometryType)ftype, pFields, m_pSptRef, &pNewFeatureClass);
		if (pNewFeatureClass)
			CDialog::OnOK();
		else
		{
			if (hr == 0x80110005L)
				lbuf = L"Layer name had exist!";
			else
				lbuf.Format(L"Create error=%d(0x%x)\n", hr, hr);

			MessageBox(lbuf);
		}
	}
}

void CDlgNewLayer::OnBnClickedBtnadd()
{
	std::vector<CString> vecName;
	for (int i = 0; i < m_list.GetItemCount(); i++)
		vecName.push_back(m_list.GetItemText(i, 0));

	CDlgAddField dlg;
	dlg.m_pvecUsedName = &vecName;
	if (dlg.DoModal() != IDOK || !dlg.m_bOK)
		return;

	int nLen = dlg.m_nLength;
	int nDec = dlg.m_nPrecision;
	SGCore::SGOFieldType ftype = SGCore::SGO_FT_NULL;
	CString strType;
	switch (dlg.m_nType)
	{
	case 0: // String
		ftype = SGCore::SGO_FT_BSTR;
		if (nLen == 0 || nLen > 254)
			nLen = 254;
		nDec = 0;
		strType = L"Text";
		break;
	case 1: // Short
		ftype = SGCore::SGO_FT_SmallInt;
		if (nLen == 0)
			nLen = 4;
		strType = L"Short";
		break;
	case 2: // Long
		ftype = SGCore::SGO_FT_Integer;
		if (nLen == 0)
			nLen = 9;
		strType = L"Long";
		break;
	case 3: // Float
		ftype = SGCore::SGO_FT_Single;
		if (nLen == 0)
		{
			nLen = 13;
			nDec = 11;
		}
		if (nLen - nDec < 2)
			nLen = nDec + 2;
		strType = L"Float";
		break;
	case 4: // Double
		ftype = SGCore::SGO_FT_Double;
		if (nLen == 0)
		{
			nLen = 19;
			nDec = 11;
		}
		if (nLen - nDec < 2)
			nLen = nDec + 2;
		strType = L"Double";
		break;
	case 5: // Date
		ftype = SGCore::SGO_FT_Date;
		nLen = 8;
		nDec = 0;
		strType = L"Date";
		break;
	case 6: // Logical
		ftype = SGCore::SGO_FT_Boolean;
		nLen = 1;
		nDec = 0;
		strType = L"Logical";
		break;
	default:
		nLen = 0;
		nDec = 0;
		break;
	}
	int nRow = m_list.InsertItem(m_list.GetItemCount(), dlg.m_strName);
	m_list.SetItemText(nRow, 1, strType);
	CString strNum;
	strNum.Format(_T("%d"), nLen);
	m_list.SetItemText(nRow, 2, strNum);
	strNum.Format(_T("%d"), nDec);
	m_list.SetItemText(nRow, 3, strNum);

	m_list.SetItemData(nRow, dlg.m_nType);
	m_Type.push_back(dlg.m_nType);

	m_Alias.push_back(dlg.m_strAlias);
	GetDlgItem(IDOK)->EnableWindow();
}

void CDlgNewLayer::OnBnClickedBtnemove()
{
	UINT sct = m_list.GetSelectedCount();
	if (sct == 0)
		return;

	std::vector<UINT> selItems;
	POSITION pos = m_list.GetFirstSelectedItemPosition();
	while (pos != NULL)
		selItems.push_back(m_list.GetNextSelectedItem(pos));

	for (std::vector<UINT>::reverse_iterator prIter = selItems.rbegin(); prIter != selItems.rend(); prIter++)
		m_list.DeleteItem(*prIter);

	for (std::vector<UINT>::reverse_iterator prIter = selItems.rbegin(); prIter != selItems.rend(); prIter++)
		m_Type.erase(m_Type.begin() + *prIter);

	for (std::vector<UINT>::reverse_iterator prIter = selItems.rbegin(); prIter != selItems.rend(); prIter++)
		m_Alias.erase(m_Alias.begin() + *prIter);

	(m_list.GetItemCount() == 0) ? GetDlgItem(IDOK)->EnableWindow(FALSE) : GetDlgItem(IDOK)->EnableWindow();
}

void CDlgNewLayer::OnTimer(UINT_PTR nIDEvent)
{
	if (nIDEvent == 1122)
	{
		UINT sct = m_list.GetSelectedCount();
		if (sct == 0)
			GetDlgItem(IDC_BTNREMOVE)->EnableWindow(FALSE);
		else
			GetDlgItem(IDC_BTNREMOVE)->EnableWindow();
	}

	CDialog::OnTimer(nIDEvent);
}

void CDlgNewLayer::OnDestroy()
{
	KillTimer(1122);
	CDialog::OnDestroy();
}