========================================================================
    ACTIVE TEMPLATE LIBRARY�GArcGDB �M�׷��[
========================================================================
CreateDataset();
ferr=m_pGeoDatabase->CreateFeatureDataset(dpath, sr);
	GDB_E_NAMEISALREADYUSED

DeleteDataset(bIncludeChilds); // same as DeleteTable(); ?
GetDatasetSpatialReference()
GetGeometryType() //1,2,3 //1000,2000



CreateTable2  ��GeometryType�Pint�[z,m
		geodef.SetGeometryType(geotype);
		geodef.SetHasZ(false);
		geodef.SetHasM(false);

