// DlgTables.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgTables.h"
#include "DlgProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDlgTables ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTables, CDialog)

CDlgTables::CDlgTables(SGCore::IDBWorkspacePtr pWS, SGCore::INameCollectionPtr pTables, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTables::IDD, pParent)
{
	m_pWS = pWS;
	m_pTables = pTables;
}

CDlgTables::~CDlgTables()
{
}

void CDlgTables::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_LIST2, m_list2);
}


BEGIN_MESSAGE_MAP(CDlgTables, CDialog)
	ON_LBN_SELCHANGE(IDC_LIST1, &CDlgTables::OnLbnSelchangeList1)
	ON_BN_CLICKED(IDOK, &CDlgTables::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BTNSELALL, &CDlgTables::OnBnClickedBtnselall)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTNPROP, &CDlgTables::OnBnClickedBtnprop)
END_MESSAGE_MAP()


// CDlgTables �T���B�z�`��

BOOL CDlgTables::OnInitDialog()
{
	CDialog::OnInitDialog();

	DWORD dwStyle = m_list2.GetExtendedStyle();
	dwStyle |= (LVS_EX_SUBITEMIMAGES); //  | LVS_EX_CHECKBOXES);
	m_list2.SetExtendedStyle(dwStyle);
	if (m_imglist.GetSafeHandle() == NULL)
	{
		m_imglist.Create(16, 16, ILC_MASK | ILC_COLOR32, 4, 4);
		HICON hico = AfxGetApp()->LoadIcon(IDI_TABLE);
		m_imglist.Add(hico);
		m_imglist.Add(AfxGetApp()->LoadIcon(IDI_POINT));
		m_imglist.Add(AfxGetApp()->LoadIcon(IDI_LINE));
		m_imglist.Add(AfxGetApp()->LoadIcon(IDI_POLYGON));
		m_list2.SetImageList(&m_imglist, LVSIL_SMALL); //LVSIL_NORMAL , LVSIL_SMALL
	}
	m_list2.SetRedraw(FALSE);
	long cnt;
	m_pTables->get_NameCount(&cnt);
	int lw = 200;
	// http://dd654321.pixnet.net/blog/post/311157184-%5Bc-c%2B%2B%5D%5Bmfc%5D%E8%A8%AD%E5%AE%9Astatic-text%E5%AF%AC%E5%BA%A6
	CDC *pDC = GetDlgItem(IDC_LIST2)->GetDC();
	for (int i = 0; i < cnt; i++)
	{
		CString tbuf = m_pTables->GetName(i);
		CSize sz = pDC->GetTextExtent(tbuf);
		if (lw < sz.cx)
			lw = sz.cx;
	}
	ReleaseDC(pDC);
	TRACE("cnt=%d, lw=%d\n",cnt, lw);
	m_list2.InsertColumn(0, L"Path", LVCFMT_LEFT, lw+5, 0);
	for (int i = 0; i < cnt; i++)
	{
		_bstr_t name = m_pTables->GetName(i);

		//m_list.AddString((LPCTSTR)name);
		SGCore::SGOGeometryType type = m_pWS->FieldGeometryType(name, _T(""));
		//m_list2.InsertItem(LVIF_IMAGE | LVIF_TEXT | LVIF_PARAM, i, (LPCTSTR)name, 0, 0, (int)type, 0);
		CString tbuf=name;
		m_list2.InsertItem(i, tbuf, (int)type);
	}
	m_list2.SetRedraw();
	//GetDlgItem(IDOK)->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}

void CDlgTables::OnLbnSelchangeList1()
{
	int cnt = m_list.GetSelCount();
	GetDlgItem(IDOK)->EnableWindow(cnt > 0);
}

void CDlgTables::OnBnClickedOk()
{
	m_selTables.RemoveAll();
	int cnt = m_list.GetSelCount();
	//CArray<int, int> aryListBoxSel;
	//aryListBoxSel.SetSize(cnt);

	//m_list.GetSelItems(cnt, aryListBoxSel.GetData()); 

	for (int i = 0; i < cnt; i++)
	{
		CString tmp;
		//m_list.GetText(aryListBoxSel[i], tmp);
		m_selTables.Add(tmp);
	}
	TCHAR szBuffer[MAX_PATH] = TEXT("");
	LVITEM lvi;
	lvi.iItem = 0;
	lvi.mask = LVIF_TEXT;
	lvi.cchTextMax = MAX_PATH;
	lvi.iSubItem = 0;
	lvi.pszText = szBuffer;
	for (int i = 0; i < m_list2.GetItemCount(); i++)
	{
		if (m_list2.GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)
		//if (m_list2.GetCheck(i))
		{
			lvi.iItem = i;
			if (m_list2.GetItem(&lvi))
				m_selTables.Add(szBuffer);
			memset(szBuffer, 0, MAX_PATH);
		}
	}
	if (m_selTables.GetCount() == 0)
	{
		MessageBox(L"Please select...");
		return;
	}
	OnOK();
}

// https://blog.csdn.net/to_Baidu/article/details/61428276
void CDlgTables::OnBnClickedBtnselall()
{
	//m_list.SetRedraw(FALSE);
	//BOOL bSel = (m_list.GetCount() != m_list.GetSelCount());
	//for (int i = 0; i < m_list.GetCount(); i++)
	//{
	//	m_list.SetSel(i, bSel);
	//}
	//m_list.SetRedraw(TRUE);
	//GetDlgItem(IDOK)->EnableWindow(bSel);

	int seln = 0;
	for (int i = 0; i < m_list2.GetItemCount(); i++)
		if (m_list2.GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)
		//if (m_list2.GetCheck(i))
			seln++;

	BOOL bSel = (m_list2.GetItemCount() != seln);
	m_list2.SetRedraw(FALSE);
	for (int i = 0; i < m_list2.GetItemCount(); i++)
	{
		//m_list2.SetCheck(i, bSel);
		m_list2.SetItemState(i, (bSel ? LVIS_SELECTED : 0), LVIS_SELECTED); // LVIS_SELECTED | LVIS_FOCUSED
	}
	m_list2.SetRedraw(TRUE);
	//m_list2.Invalidate();
	//m_list2.UpdateWindow();
	m_list2.SetFocus(); //�n�[��,�~�|���G�ϥ�
}

// https://docs.microsoft.com/zh-tw/visualstudio/debugger/finding-memory-leaks-using-the-crt-library?view=vs-2015
void CDlgTables::OnClose()
{
	m_list2.DeleteAllItems();

	CDialog::OnClose();
}


void CDlgTables::OnBnClickedBtnprop()
{
	SGFileGDB::IGDBWorkspacePtr pWS = m_pWS;
	if (pWS)
	{
		SGCore::INameCollectionPtr pNames=pWS->DomainNames();
		if (pNames && pNames->GetNameCount() > 0)
		{
			int n = pNames->GetNameCount();
			for (int i = 0; i < n; i++)
			{
				_bstr_t name = pNames->GetName(i);
				_bstr_t def = pWS->GetDomainDefinition(name);
			}
			CDlgProp dlg(m_pWS, pNames, this);
			dlg.DoModal();
			return;
		}
	}
	MessageBox(L"No Domains");
}
