// ExtButton.cpp : CExtButton ����@

#include "stdafx.h"
#include "ExtButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CExtButton

STDMETHODIMP CExtButton::raw_InitItem(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	//m_pApp = Parent;

	return S_OK;
}



STDMETHODIMP CExtButton::raw_OnCommand(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());


	return S_OK;
}
