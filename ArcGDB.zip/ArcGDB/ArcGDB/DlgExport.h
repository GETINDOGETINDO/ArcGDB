#pragma once


// CDlgExport ��ܤ��

class CDlgExport : public CDialog
{
	DECLARE_DYNAMIC(CDlgExport)

public:
	CDlgExport(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgExport();
	CString m_output;
	CArray<LAYInfo>* m_pSels;

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_EXPORT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

private:
	CComboBox m_cboLay;
	CListBox m_lst;
	SGDataSelect::IDataSelector2Ptr m_pSel;

public:
	afx_msg void OnBnClickedBtnopen();
	afx_msg void OnBnClickedBtnadd();
	afx_msg void OnBnClickedBtndel();
	afx_msg void OnBnClickedBtnpath();
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeCbolay();
	CString m_dataset;

};
