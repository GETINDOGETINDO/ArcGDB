#pragma once
#include "afxwin.h"


// CDlgImport ��ܤ��

class CDlgImport : public CDialog
{
	DECLARE_DYNAMIC(CDlgImport)

public:
	CDlgImport(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgImport();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_IMPORT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	CArray<SGCore::IMapLayerPtr, SGCore::IMapLayerPtr>* m_pLays;
	CString m_outputGDB;
	CString m_dataset;

private:
	bool m_bLockOutput;
	CComboBox m_cboLay;
	CListBox m_lst;
	SGDataSelect::IDataSelector2Ptr m_pSel;
	CArray<SGCore::IFeatureLayerPtr> m_openLays;
	CArray<SGCore::IMapLayerPtr, SGCore::IMapLayerPtr> m_Lays;

public:
	afx_msg void OnBnClickedBtnopen();
	afx_msg void OnBnClickedBtnadd();
	afx_msg void OnBnClickedBtndel();
	afx_msg void OnBnClickedBtnpath();
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeCbolay();
	
};
