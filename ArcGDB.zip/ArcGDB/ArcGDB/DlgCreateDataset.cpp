// DlgCreateDataset.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgCreateDataset.h"
//#include "afxdialogex.h"


// CDlgCreateDataset ��ܤ��

IMPLEMENT_DYNAMIC(CDlgCreateDataset, CDialog)

CDlgCreateDataset::CDlgCreateDataset(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CREATEDATASET, pParent)
	, m_name(_T(""))
{

}

CDlgCreateDataset::~CDlgCreateDataset()
{
}

void CDlgCreateDataset::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_NAME, m_name);
}


BEGIN_MESSAGE_MAP(CDlgCreateDataset, CDialog)
	ON_BN_CLICKED(IDC_SELECT_COORD, &CDlgCreateDataset::OnBnClickedSelectCoord)
	ON_BN_CLICKED(IDOK, &CDlgCreateDataset::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgCreateDataset �T���B�z�`��


void CDlgCreateDataset::OnBnClickedSelectCoord()
{
	SGUserInterface::ICSSelectorPtr pCS(SGUserInterface::CLSID_CSSelector);
	_bstr_t bstr = pCS->Show();
	if (bstr.length() == 0)
		return;
	m_pSptRef = pCS->SpatialReference;
	GetDlgItem(IDC_COORD_NAME)->SetWindowText(m_pSptRef->Name);
}


void CDlgCreateDataset::OnBnClickedOk()
{
	UpdateData();
	m_name = m_name.Trim();
	if (m_name.IsEmpty())
	{
		MessageBox(L"Name input error!");
		return;
	}
	if (m_pGdb)
	{
		IUnknownPtr pUnk; //=m_pSptRef;
		HRESULT hr = 0; //m_pGdb->raw_CreateDataset(_bstr_t(m_name), pUnk);
		if (hr==S_OK)
			CDialog::OnOK();
		else
			MessageBox((hr==0x80110005L) ? L"Dataset had exist!" : L"Ceate dataset error!");
	}
}
