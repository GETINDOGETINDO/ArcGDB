//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ͪ� Include �ɮסC
// �� ArcGDB.rc �ϥ�
//
#define IDS_PROJNAME                    100
#define IDR_ARCGDB                      101
#define IDS_NAME                        101
#define IDS_TYPE                        102
#define IDR_EXTBAR                      103
#define IDS_LENGTH                      103
#define IDS_PRECISION                   104
#define IDR_EXTBUTTON                   105
#define IDS_TYPESTRING                  105
#define IDR_BTNOPEN                     106
#define IDS_TYPESHORT                   106
#define IDR_BTNCREATE                   107
#define IDS_TYPELONG                    107
#define IDR_BTNIMPORT                   108
#define IDS_TYPEFLOAT                   108
#define IDS_TYPEDOUBLE                  109
#define IDS_TYPEDATE                    110
#define IDS_TYPELOGICAL                 111
#define IDS_MSG1                        112
#define IDS_MSG4                        113
#define IDD_TABLES                      201
#define IDC_LIST1                       201
#define IDC_BUTTON1                     202
#define IDC_BTNSELALL                   202
#define IDD_PROP                        202
#define IDC_BTNPATH                     202
#define IDC_LIST2                       203
#define IDI_LINE                        203
#define IDC_BTNOPEN                     203
#define IDI_POINT                       204
#define IDC_BTNPROP                     204
#define IDC_LIST3                       204
#define IDC_NAME                        204
#define IDC_BTNADD                      204
#define IDI_POLYGON                     205
#define IDC_LIST4                       205
#define IDC_PATH                        205
#define IDC_NAME2                       205
#define IDI_TABLE                       206
#define IDC_BTNDEL                      206
#define IDI_ADD                         207
#define IDC_LBNAME                      207
#define IDC_BTNUP                       207
#define IDI_BROWSE                      208
#define IDC_LBPATH                      208
#define IDC_BTNDOWN                     208
#define IDI_DEL                         209
#define IDC_LBFEATURES                  209
#define IDI_DOWN                        210
#define IDC_LBGDB                       210
#define IDI_UP                          211
#define IDC_CBOLAY                      211
#define IDD_CREATE                      212
#define IDC_LIST                        212
#define IDD_IMPORT                      213
#define IDC_LBDATASET                   213
#define IDC_DATASET                     214
#define IDD_CREATE1                     214
#define IDD_NEWLAYER                    214
#define IDI_EXCEL                       214
#define IDC_TYPE                        215
#define IDD_CREATE2                     215
#define IDD_ADD_FIELD                   215
#define IDI_DB                          215
#define IDC_SELECT_COORD                216
#define IDD_CREATEDATASET               216
#define IDR_GDBMENU                     216
#define IDC_COORD_NAME                  217
#define IDD_GDBLIST                     217
#define IDC_LISTFIELD                   218
#define IDD_EXPORT                      218
#define IDC_BTNREMOVE                   219
#define IDC_ADDZ                        220
#define IDC_LBLTYPE                     221
#define IDC_LBLFIELD                    222
#define IDC_LBLCOORD                    223
#define IDC_FNAME                       224
#define IDC_FTYPE                       225
#define IDC_FLENGTH                     226
#define IDC_FPRECISION                  227
#define IDC_FALIAS                      228
#define IDC_LBLFNAME                    229
#define IDC_LBLFTYPE                    230
#define IDC_LBLFLENGTH                  231
#define IDC_LBLFPRECISION               232
#define IDC_LBLFALIAS                   233
#define IDC_TREE                        233
#define ID__NEWFEATUREDATASET           32768
#define ID__NEWFEATURECLASS             32769
#define ID__IMPORTFEATURECLASS          32770
#define ID__EXPORTFEATURECLASS          32771
#define ID__REMOVEFROMLIST              32772
#define ID__DELETEFROMGDB               32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        217
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         234
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
