// BtnImport.cpp : CBtnImport ����@

#include "stdafx.h"
#include "BtnImport.h"
#include "SGUtils.h"
#include "dlgGDBList.h"
#include "dlgImport.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CBtnImport

STDMETHODIMP CBtnImport::raw_InitItem(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	m_pApp = Parent;

	return S_OK;
}

STDMETHODIMP CBtnImport::raw_ExitItem(void) 
{ 
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	m_pApp = NULL;  
	return S_OK; 
}



STDMETHODIMP CBtnImport::raw_OnCommand(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	SGCore::IMapPtr pMap;
	if (Parent)
		pMap = Parent->GetMap();
	else if (m_pApp)
		pMap=m_pApp->GetMapView()->GetMap();

	CDlgGDBList dlgt;
	dlgt.DoModal();
	return S_OK;


	CArray<SGCore::IMapLayerPtr, SGCore::IMapLayerPtr> fls;
	RetrieveLayerCollection(pMap, &fls, TRUE);
	CDlgImport dlg;
	dlg.m_pLays = &fls;
	if (dlg.DoModal() != IDOK)
		return S_OK;

	return S_OK;
}
