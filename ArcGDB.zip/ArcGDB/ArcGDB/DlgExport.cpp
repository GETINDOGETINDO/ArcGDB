// DlgExport.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "SGUtils.h"
#include "DlgExport.h"
//#include "afxdialogex.h"
#include "DirDialog.h"


CString s_outPath=L"";

CString transformTableName(CString tname, int type, bool bGDBname)
{
	CString gdbname;
	CString dname;
	CString fname;
	CString buf = tname;
	int fi;
	int i = 0;
	for (; i<3; i++)
	{
		fi = buf.ReverseFind(L'\\');
		if (fi<0)
			fi = buf.ReverseFind(L'/');
		if (fi < 0)
			break;

		if (i==0)
			fname = buf.Mid(fi + 1);
		else if (i == 1)
		{
			if (type < 20000)
			{
				gdbname = buf.Mid(fi + 1);
				break;
			}
			dname= buf.Mid(fi + 1);
		}
		else if (i == 2)
		{
			gdbname = buf.Mid(fi + 1);
			break;
		}
		buf = buf.Left(fi);
	}
	if (fname.IsEmpty())
		return tname;

	buf = fname;
	if (!dname.IsEmpty())
		buf = dname + L"\\" + fname;
	if (bGDBname && !gdbname.IsEmpty())
		buf = gdbname + L"\\" + buf;

	return buf;
}

// CDlgExport ��ܤ��

IMPLEMENT_DYNAMIC(CDlgExport, CDialog)

CDlgExport::CDlgExport(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_EXPORT, pParent)
{
	m_pSels = NULL;
}

CDlgExport::~CDlgExport()
{
}

void CDlgExport::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_PATH, m_output);
	DDX_Control(pDX, IDC_CBOLAY, m_cboLay);
	DDX_Control(pDX, IDC_LIST, m_lst);
}


BEGIN_MESSAGE_MAP(CDlgExport, CDialog)
	ON_BN_CLICKED(IDC_BTNOPEN, &CDlgExport::OnBnClickedBtnopen)
	ON_BN_CLICKED(IDC_BTNADD, &CDlgExport::OnBnClickedBtnadd)
	ON_BN_CLICKED(IDC_BTNDEL, &CDlgExport::OnBnClickedBtndel)
	ON_BN_CLICKED(IDC_BTNPATH, &CDlgExport::OnBnClickedBtnpath)
	ON_BN_CLICKED(IDOK, &CDlgExport::OnBnClickedOk)
	ON_CBN_SELCHANGE(IDC_CBOLAY, &CDlgExport::OnCbnSelchangeCbolay)
END_MESSAGE_MAP()


// CDlgExport �T���B�z�`��
void CDlgExport::OnBnClickedBtnopen()
{
}

void CDlgExport::OnBnClickedBtnadd()
{
	UpdateData();
	CString buf;
	m_cboLay.GetWindowText(buf);
	buf = buf.Trim();
	if (!buf.IsEmpty())
	{
		CString buf2;
		for (int i = 0; i < m_lst.GetCount(); i++)
		{
			m_lst.GetText(i, buf2);
			if (buf.CompareNoCase(buf2) == 0)
			{
				MessageBox(L"Had add!");
				return;
			}
		}
		long ki = 0; // m_openLays.Add(pFL) + 1;
		long ai = m_lst.AddString(buf);
		m_lst.SetItemData(ai, -ki);
	}
}


void CDlgExport::OnBnClickedBtndel()
{
	if (m_lst.GetSelCount())
	{
		for (int i = 0; i<m_lst.GetCount(); i++)
			if (m_lst.GetSel(i))
				m_lst.DeleteString(i--);
	}
}


void CDlgExport::OnBnClickedBtnpath()
{
	UpdateData();
	CDirDialog dd;
	dd.m_strTitle = L"Select output path";
	dd.m_strSelDir = m_output;
	if (!dd.DoBrowse(AfxGetMainWnd()))
		return;

	//SGFileGDB::IGDBWorkspacePtr pGWS(SGFileGDB::CLSID_GDBWorkspace);
	//if (!pGWS->Open(_bstr_t(dd.m_strPath)))
	//	MessageBox(_T("Not a valid FileGDB Folder!"));
	//else
	if (!OutPathExist(dd.m_strPath, TRUE))
		MessageBox(_T("Not a valid output folder!"));
	else
		m_output = dd.m_strPath;

	UpdateData(FALSE);
}


void CDlgExport::OnBnClickedOk()
{
	UpdateData();
	int n = m_lst.GetCount();
	if (n <= 0)
	{
		MessageBox(_T("Please Input Features!"));
		return;
	}
	m_output = m_output.Trim();
	if (m_output.IsEmpty())
	{
		MessageBox(_T("Please Input Output path!"));
		return;
	}
	if (!OutPathExist(m_output, TRUE))
	{
		MessageBox(_T("Not a valid output folder!"));
		return;
	}
	s_outPath = m_output;
	CString outPath = m_output;
	if (outPath.Right(1) != L"\\")
		outPath += L"\\";

	SGFileGDB::IGDBWorkspacePtr pGWS;
	CWaitCursor cur;
	this->EnableWindow(FALSE);
	SGCore::IDBWorkspacePtr pWS = pGWS;

	SGCore::IFeatureClassPtr pFeatureClass;
	SGSFCOMS::ISpatialReferencePtr pSR;
	SGCore::IFeatureCursorPtr pFCur;

	CString lbuf;
	CString buf;
	SGCore::SGOGeometryType type = SGCore::SGO_GT_Unknown;
	for (int i = 0; i < n; i++)
	{
		long id = m_lst.GetItemData(i);
		if (id <= 0)
			continue;

		pWS=m_pSels->GetAt(id - 1).pUnk;
		if (pWS == NULL)
		{
			TRACE("export(%d) id=%d pWS=NULL\n", i, id);
			continue;
		}

		CString layername= transformTableName(m_pSels->GetAt(id - 1).name, m_pSels->GetAt(id - 1).type, false);
		pFeatureClass = pWS->OpenTable(_bstr_t(layername), L"SHAPE", type);
		if (pFeatureClass==NULL)
		{
			buf.Format(L"Open err=%s\r\n", m_pSels->GetAt(id - 1).name);
			lbuf += buf;
			continue;
		}
		layername.Replace(L'\\', L'_');
		//layername.Replace(L'/', L'_');
		type = pFeatureClass->FeatureType;
		if (type == SGCore::SGO_GT_Unknown)  //pure table
		{

		}
		else
		{
			bool bZ = false;
			SGCore::IFeatureClassPtr pNewFeatureClass = NULL;
			SGCore::IFieldsPtr pSrcFields;
			SGCore::IGeoDatasetPtr pGD = pFeatureClass;
			pGD->get_SpatialReference(&pSR);
			pFeatureClass->get_Fields(&pSrcFields);
			SGDataAccess::IShapeFileFeatureClass3Ptr pNewShpCls;
			pNewShpCls.CreateInstance(SGDataAccess::CLSID_ShapeFileFeatureClass);

			SGDataAccess::SGOShapeType stype = SGDataAccess::SGO_ST_NullShape;
			if (type == SGCore::SGO_GT_Point)
				stype = (bZ) ? SGDataAccess::SGO_ST_PointZ : SGDataAccess::SGO_ST_Point;
			else if (type == SGCore::SGO_GT_LineString)
				stype = (bZ) ? SGDataAccess::SGO_ST_PolyLineZ : SGDataAccess::SGO_ST_PolyLine;
			else if (type == SGCore::SGO_GT_Polygon)
				stype = (bZ) ? SGDataAccess::SGO_ST_PolygonZ : SGDataAccess::SGO_ST_Polygon;

			layername += L".shp";
			CString shpfile = outPath + layername;
			VARIANT_BOOL bRet = VARIANT_FALSE;
			HRESULT hr = pNewShpCls->raw_CreateFile(_bstr_t(shpfile), pSrcFields, CP_UTF8, stype, pSR, &bRet);

			if (pNewFeatureClass && bRet)
			{
				pFCur = pFeatureClass->Search(NULL);
				CopyRecords(pNewFeatureClass, pSrcFields, pFCur, FALSE, TRUE);
			}
			else
			{
				buf.Format(L"%s(err=%ld(0X%x))\r\n", layername, hr, hr);
				lbuf += buf;
			}
		}
	}
	this->EnableWindow();
	if (lbuf.IsEmpty())
	{
		MessageBox(L"Export OK.");
		CDialog::OnOK();
	}
	else
	{
		lbuf = L"Export following err:\r\n" + lbuf;
		MessageBox(lbuf);
	}
}


BOOL CDlgExport::OnInitDialog()
{
	CDialog::OnInitDialog();
	((CButton*)(this->GetDlgItem(IDC_BTNOPEN)))->SetIcon(AfxGetApp()->LoadIcon(IDI_BROWSE));
	((CButton*)(this->GetDlgItem(IDC_BTNADD)))->SetIcon(AfxGetApp()->LoadIcon(IDI_ADD));
	((CButton*)(this->GetDlgItem(IDC_BTNDEL)))->SetIcon(AfxGetApp()->LoadIcon(IDI_DEL));

	m_output = s_outPath;
#ifdef _DEBUG
	if (m_output.IsEmpty())
		m_output = L"f:\\test\\gdb\\export";
#endif

	m_cboLay.AddString(L"");
	if (m_pSels)
	{
		GetDlgItem(IDC_BTNOPEN)->ShowWindow(SW_HIDE);
		for (long i = 0; i < m_pSels->GetCount(); i++)
		{
			LAYInfo* pLay = &(m_pSels->GetAt(i));
			CString buf = pLay->name;
			//if (pLay->type >= 20000)  //
				
			int ai = m_cboLay.AddString(buf);
			m_cboLay.SetItemData(ai, i + 1);   //use base 1
			ai=m_lst.AddString(buf);
			m_lst.SetItemData(ai, i+1);
		}
	}
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}


void CDlgExport::OnCbnSelchangeCbolay()
{
	UpdateData();
	int seli = m_cboLay.GetCurSel();
	TRACE("seli=%d\n", seli);
	if (seli > 0)
	{
		long ki = m_cboLay.GetItemData(seli);
		for (int i = 0; i < m_lst.GetCount(); i++)
		{
			if (ki == m_lst.GetItemData(i))
			{
				MessageBox(L"Had add!");
				m_cboLay.SetWindowText(L"");
				m_cboLay.SetCurSel(-1);
				return;
			}
		}
		CString buf;
		m_cboLay.GetLBText(seli, buf);
		long ai = m_lst.AddString(buf);
		m_lst.SetItemData(ai, ki);
		m_cboLay.SetWindowText(L"");
		m_cboLay.SetCurSel(-1);
	}
}
