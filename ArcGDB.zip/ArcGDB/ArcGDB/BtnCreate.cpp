// BtnCreate.cpp : CBtnCreate ����@

#include "stdafx.h"
#include "BtnCreate.h"
#include "dlgCreate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CBtnCreate



STDMETHODIMP CBtnCreate::raw_OnCommand(SGCore::ICommandTarget *Parent)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	//Name, Path
	CDlgCreate dlg;
	if (dlg.DoModal() != IDOK)
		return S_OK;

	return S_OK;
}
