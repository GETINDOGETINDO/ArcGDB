#pragma once
#include <vector>

// CDlgAddField ��ܤ��

class CDlgAddField : public CDialog
{
	DECLARE_DYNAMIC(CDlgAddField)

public:
	CDlgAddField(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgAddField();

	CComboBox	m_oType;
	CString	m_strName;
	CString	m_strAlias;
	int		m_nType;
	int		m_nLength;
	int		m_nPrecision;
	BOOL	m_bOK;
	std::vector<CString>* m_pvecUsedName;

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ADD_FIELD };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeType();
	virtual void OnOK();
	afx_msg void OnEnChangeName();
};
