#pragma once


// CDlgCreate ��ܤ��

class CDlgCreate : public CDialog
{
	DECLARE_DYNAMIC(CDlgCreate)

public:
	CDlgCreate(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgCreate();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CREATE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	CString m_name;
	CString m_outputPath;
	afx_msg void OnBnClickedBtnpath();
	afx_msg void OnBnClickedOk();
};
