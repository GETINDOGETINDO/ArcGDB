// DlgGDBList.cpp : ��@��
//

#include "stdafx.h"
#include "ArcGDB.h"
#include "DlgGDBList.h"
//#include "afxdialogex.h"

#include "DlgCreateDataset.h"
#include "DlgNewLayer.h"
#include "DlgImport.h"
#include "DlgExport.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CDlgGDBList ��ܤ��

IMPLEMENT_DYNAMIC(CDlgGDBList, CDialog)

CDlgGDBList::CDlgGDBList(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_GDBLIST, pParent)
{

}

CDlgGDBList::~CDlgGDBList()
{
}

void CDlgGDBList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TREE, m_tree);
}


BEGIN_MESSAGE_MAP(CDlgGDBList, CDialog)
	ON_NOTIFY(NM_RCLICK, IDC_TREE, &CDlgGDBList::OnNMRClickTree)
	ON_NOTIFY(TVN_BEGINDRAG, IDC_TREE, &CDlgGDBList::OnTvnBegindragTree)
	ON_WM_SIZING()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDOK, &CDlgGDBList::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgGDBList �T���B�z�`��
BOOL CDlgGDBList::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_imageList.Create(16, 16, ILC_COLOR8, 6, 1);
	m_imageList.Add(AfxGetApp()->LoadIcon(IDI_TABLE));
	m_imageList.Add(AfxGetApp()->LoadIcon(IDI_POINT));
	m_imageList.Add(AfxGetApp()->LoadIcon(IDI_LINE));
	m_imageList.Add(AfxGetApp()->LoadIcon(IDI_POLYGON));
	m_imageList.Add(AfxGetApp()->LoadIcon(IDI_EXCEL));
	m_imageList.Add(AfxGetApp()->LoadIcon(IDI_DB));
	m_tree.SetImageList(&m_imageList, TVSIL_NORMAL);
	//http://computer-programming-forum.com/82-mfc/7d34213fbb382aeb.htm
	//https://www.codeguru.com/cpp/controls/treeview/misc-advanced/article.php/c723/Allowing-multiple-selection.htm
	m_tree.SetExtendedStyle(TVS_EX_MULTISELECT, TVS_EX_MULTISELECT);
	GetWindowRect(m_rcInit);
	Reload();
	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX �ݩʭ����Ǧ^ FALSE
}
static int CALLBACK MyCompareProc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	//CSuperGISToolkitView* pView = (CSuperGISToolkitView*)lParamSort;
	//CTreeCtrl &tc = pView->GetTreeCtrl();

	//long id1 = (long)lParam1;
	//long id2 = (long)lParam2;
	//MSXML2::IXMLDOMElementPtr pElem1 = pView->m_vcElem[id1];
	//MSXML2::IXMLDOMElementPtr pElem2 = pView->m_vcElem[id2];

	//BOOL bGroup1 = (!IsTool(pElem1) && !IsProcess(pElem1));
	//BOOL bGroup2 = (!IsTool(pElem2) && !IsProcess(pElem2));

	//CString s1, s2;
	//_variant_t val;
	//pElem1->raw_getAttribute(_T("name"), &val);
	//s1 = val;
	//pElem2->raw_getAttribute(_T("name"), &val);
	//s2 = val;

	//if (bGroup1 == bGroup2)
	//	return _wcsicmp(s1, s2);
	//else if (bGroup1)
	//	return -1;
	//else
	//	return 1;
	return 0;
}

void CDlgGDBList::Sort(HTREEITEM hParent)
{
	TVSORTCB tvs;
	tvs.hParent = hParent;
	tvs.lpfnCompare = MyCompareProc;
	tvs.lParam = (LPARAM)this;
	m_tree.SortChildrenCB(&tvs);
}


void CDlgGDBList::Reload()
{
	m_tree.SetRedraw(FALSE);
	m_tree.DeleteAllItems();
	HTREEITEM hRoot = NULL;
	HTREEITEM hParent= NULL;
	CString name;
	int nImage = 0;
	HTREEITEM hItem = NULL;
#ifdef _DEBUG2
	hParent = m_tree.InsertItem(_T("GDB1"),5,5);
	m_tree.SetItemData(hParent, 5);
	nImage = 1;
	hItem = m_tree.InsertItem(L"pt", nImage, nImage, hParent);
	m_tree.SetItemData(hItem, 1);
	nImage = 2;
	hItem = m_tree.InsertItem(L"line", nImage, nImage, hParent);
	m_tree.SetItemData(hItem, 2);
	nImage = 3;
	hItem = m_tree.InsertItem(L"polygon", nImage, nImage, hParent);
	m_tree.SetItemData(hItem, 3);

	hParent = m_tree.InsertItem(_T("GDB2"), 5, 5);
	m_tree.SetItemData(hParent, 5);
	nImage = 0;
	hItem = m_tree.InsertItem(L"tb", nImage, nImage, hParent);
	m_tree.SetItemData(hItem, 0);
	nImage = 4;
	hItem = m_tree.InsertItem(L"set", nImage, nImage, hParent);
	m_tree.SetItemData(hItem, 4);
	hParent = hItem;
	nImage = 2;
	hItem = m_tree.InsertItem(L"line", nImage, nImage, hParent);
	m_tree.SetItemData(hItem, 2);

	return;
#endif

	SGFileGDB::IGDBWorkspacePtr pGWS;
	SGCore::IDBWorkspacePtr pWS;
	SGCore::INameCollectionPtr pSchemas;
	SGCore::INameCollectionPtr pTables;

	LAYInfo li;
	CArray<LAYInfo> infos; //
	GDBInfo* pInfo;
	for (int k = 0; k < g_gdbList.GetGDBCount(); k++)
	{
		pInfo=g_gdbList.GetGDB(k);
		if (pInfo->pGWS)
		{
			int ti = 0;
			CString dset=pInfo->name;
			//ti = dset.ReverseFind(L'\\');
			//if (ti<0)
			//	ti = dset.ReverseFind(L'/');
			//if (ti >= 0)
			//	dset = dset.Mid(ti + 1);

			hRoot = m_tree.InsertItem(dset, 5, 5);
			m_tree.SetItemData(hRoot, (10*k+5));
			hParent = hRoot;
			pWS = pInfo->pGWS;
			pSchemas = pWS->SchemaNames();
			if (pSchemas == NULL)
				continue;

			int nn = pSchemas->GetNameCount();  //�Ydataset�n����,�h��s=1,�̫�~0
			for (int s = 0; s < nn; s++)
			{
				infos.RemoveAll();
				pTables = pWS->TableNames(pSchemas->GetName(s));
				if (pTables == NULL)
					continue;

				long cnt=pTables->GetNameCount();
				for (int i = 0; i < cnt; i++)
				{
					_bstr_t name=pTables->GetName(i);
					CString dd = (LPCTSTR)name;
					_tcscpy_s(li.name, 256, dd);
					li.type = (int)(pWS->FieldGeometryType(name, _T("")));
					infos.Add(li);
				}
				dset = (LPCTSTR)(pSchemas->GetName(s));
				ti = dset.Find(L'\\');
				if (ti<0)
					ti = dset.Find(L'/');
				if (dset.IsEmpty() || (ti==0 && dset.GetLength()==1))
					hParent = hRoot;
				else
				{
					hParent = m_tree.InsertItem(dset.Mid(ti + 1), 4, 4, hRoot);
					m_tree.SetItemData(hParent, (10*k+4));
				}
				if (infos.GetCount() > 1)
					qsort(infos.GetData(), infos.GetCount(), sizeof(LAYInfo), qsortFunc);

				for (int i = 0; i < cnt; i++)
				{
					CString tname = infos.GetAt(i).name;
					ti = tname.FindOneOf(L"\\/");
					if (ti > 0)
						tname = tname.Mid(ti + 1);

					nImage = infos.GetAt(i).type;
					hItem = m_tree.InsertItem(tname, nImage, nImage, hParent);
					m_tree.SetItemData(hItem, (10*k+nImage));
				}
			}
		}
	}

	//m_tree.Expand(hRoot, TVE_EXPAND);
	m_tree.SetRedraw();
}

void CDlgGDBList::addSelectItem(HTREEITEM &hItem, LAYInfo& lay)
{
	lay.type = (int)m_tree.GetItemData(hItem);
	CString dd = L"";
	HTREEITEM hParent = hItem;
	while ((hParent = m_tree.GetParentItem(hParent)))
	{
		dd = m_tree.GetItemText(hParent) + L"\\" + dd;
	}
	dd += m_tree.GetItemText(hItem);
	_tcscpy_s(lay.name, 256, dd);
	//TRACE(L"sel(%d)=%ws\n", lay.type, lay.name);
}
void CDlgGDBList::traverseSelect(HTREEITEM &hItem, bool bClear)
{
	LAYInfo lay;
	if ((m_tree.GetItemState(hItem, TVIS_SELECTED) & TVIS_SELECTED))
	{
		if (bClear)
			m_tree.SetItemState(hItem, ~TVIS_SELECTED, TVIS_SELECTED);
		else
		{
			addSelectItem(hItem, lay);
			m_sels.Add(lay);
		}
	}

	HTREEITEM hItemTmp = m_tree.GetChildItem(hItem);
	while (hItemTmp != NULL)
	{
		if (m_tree.ItemHasChildren(hItemTmp))
			traverseSelect(hItemTmp, bClear);
		else if ((m_tree.GetItemState(hItemTmp, TVIS_SELECTED) & TVIS_SELECTED))
		{
			if (bClear)
				m_tree.SetItemState(hItemTmp, ~TVIS_SELECTED, TVIS_SELECTED);
			else
			{
				addSelectItem(hItemTmp, lay);
				m_sels.Add(lay);
			}
		}
		hItemTmp = m_tree.GetNextSiblingItem(hItemTmp);
	}
}
int CDlgGDBList::GetSelectItems()
{
	m_sels.RemoveAll();
	HTREEITEM hRoot = NULL;
	hRoot = m_tree.GetRootItem();
	while (hRoot)
	{
		//TRACE(L"root=%d,%d, %ws\n", m_tree.GetItemData(hRoot), m_tree.GetItemState(hRoot, TVIS_SELECTED), m_tree.GetItemText(hRoot));
		traverseSelect(hRoot, false);
		hRoot = m_tree.GetNextSiblingItem(hRoot);
	}
	return m_sels.GetCount();
}

void CDlgGDBList::clearTreeAllSelected()
{
	m_tree.SetRedraw(FALSE);
	HTREEITEM hRoot = NULL;
	hRoot = m_tree.GetRootItem();
	while (hRoot)
	{
		traverseSelect(hRoot, true);
		hRoot = m_tree.GetNextSiblingItem(hRoot);
	}
	m_tree.SetRedraw();
}

void CDlgGDBList::traverseSub(HTREEITEM& hItem, CArray<LAYInfo>& lays, bool bsel)
{
	HTREEITEM hItemTmp = m_tree.GetChildItem(hItem);
	while (hItemTmp != NULL)
	{
		bool bsel2 = (m_tree.GetItemState(hItemTmp, TVIS_SELECTED) & TVIS_SELECTED);
		if (m_tree.ItemHasChildren(hItemTmp))  //dataset
		{
			traverseSub(hItemTmp, lays, (bsel || bsel2));
		}
		else
		{
			if (bsel || bsel2)
			{
				LAYInfo lay;
				addSelectItem(hItemTmp, lay);
				int gi=(lay.type / 10);
				int fi = (lay.type % 10);
				lay.pUnk = g_gdbList.GetGDB(gi)->pGWS;
				HTREEITEM hParent=m_tree.GetParentItem(hItemTmp);
				//�˦�+10000�@��,+20000����dataset
				lay.type = 10000+fi;
				if (hParent)
				{
					if ((((int)m_tree.GetItemData(hParent)) % 10) == 4)
						lay.type = 20000 + fi;
				}
				lays.Add(lay);
			}
		}
		hItemTmp = m_tree.GetNextSiblingItem(hItemTmp);
	}
}

void CDlgGDBList::GetAllSelectedInfo(CArray<LAYInfo>& allSels)
{
	allSels.RemoveAll();
	LAYInfo info;
	//CArray<LAYInfo> lays;
	HTREEITEM hRoot = NULL;
	hRoot = m_tree.GetRootItem();
	while (hRoot)
	{
		bool bsel = (m_tree.GetItemState(hRoot, TVIS_SELECTED) & TVIS_SELECTED);
		traverseSub(hRoot, allSels, bsel);
		hRoot = m_tree.GetNextSiblingItem(hRoot);
	}
}


void CDlgGDBList::OnNMRClickTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	*pResult = 0;
	POINT ptScreen;
	if (!GetCursorPos(&ptScreen))
		return;

	TRACE("scr=%d,%d\n", ptScreen.x, ptScreen.y);
	POINT point = ptScreen;
	m_tree.ScreenToClient(&point);
	TRACE("point=%d,%d\n", point.x, point.y);
	HTREEITEM hTemp = NULL;
	UINT flag = TVHT_ONITEM;
	int seln = m_tree.GetSelectedCount();
	HTREEITEM hCurrent = m_tree.HitTest(point, &flag);
	TRACE("hitest=%x, %d seln=%d\n", hCurrent, flag, seln);
	if (hCurrent == NULL || !(flag & TVHT_ONITEMLABEL))
	{
		return;
	}
	//if (m_tree.GetSelectedItem() != hCurrent)
	//		hTemp = m_tree.GetSelectedItem();

	if (!(m_tree.GetItemState(hCurrent, TVIS_SELECTED) & TVIS_SELECTED))
	{
		//m_tree.Select(hCurrent, TVGN_CARET);
		//m_tree.SelectItem(hCurrent); //multi no use, use SetItemState()
		clearTreeAllSelected();
		m_tree.SetItemState(hCurrent, TVIS_SELECTED, TVIS_SELECTED);
		seln = 1;
	}
	//m_tree.Select(hCurrent, TVGN_CARET);
	int itmd = (int)m_tree.GetItemData(hCurrent);
	TRACE("itmd=%d\n", itmd);
	seln=GetSelectItems();

	//AFX_MANAGE_STATE(AfxGetStaticModuleState());
	CMenu menu;
	menu.LoadMenu(IDR_GDBMENU);
	CMenu *pPopup = menu.GetSubMenu(0);
	seln = m_sels.GetCount();

	int itmd3 = 0; //feature class 1~3
	int itmd4 = 0, itmd5 = 0;	 //dataset=4, gdb=5
	for (int i = 0; i < seln; i++)
	{
		itmd = (m_sels[i].type % 10);
		if (itmd == 5)
			itmd5++;
		else if (itmd == 4)
			itmd4++;
		else
			itmd3++;
	}
	TRACE("itmd345=%d, %d,%d\n", itmd3, itmd4, itmd5);
	if (itmd3 > 0) //have sel table
	{
		pPopup->RemoveMenu(ID__IMPORTFEATURECLASS, MF_BYCOMMAND);
		pPopup->RemoveMenu(ID__NEWFEATURECLASS, MF_BYCOMMAND);
		pPopup->RemoveMenu(ID__NEWFEATUREDATASET, MF_BYCOMMAND);
		pPopup->RemoveMenu(0, MF_BYPOSITION); //sep
	}
	if (itmd3 > 0 || itmd4 > 0)
	{
		pPopup->EnableMenuItem(ID__NEWFEATUREDATASET, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pPopup->EnableMenuItem(ID__REMOVEFROMLIST, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	}
	if (itmd5>0) //gdb
		pPopup->EnableMenuItem(ID__DELETEFROMGDB, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

	if (seln > 1)
	{
		pPopup->EnableMenuItem(ID__NEWFEATUREDATASET, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pPopup->EnableMenuItem(ID__NEWFEATURECLASS, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
		pPopup->EnableMenuItem(ID__IMPORTFEATURECLASS, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	}
	
	UINT nCode=pPopup->TrackPopupMenuEx(TPM_LEFTALIGN | TPM_RIGHTBUTTON, // | TPM_RETURNCMD | TPM_NONOTIFY,
		ptScreen.x, ptScreen.y, this, NULL);
	if (nCode > 0)
	{
		TRACE("menu=%x\n", nCode);
	}
}


void CDlgGDBList::OnTvnBegindragTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	TRACE("OnTvnBegindragTree\n");

	*pResult = 0;
}


BOOL CDlgGDBList::OnCommand(WPARAM wParam, LPARAM lParam)
{
	TRACE("OnCommand=%x, %x\n", wParam, lParam);
	if (wParam == ID__NEWFEATUREDATASET)
	{
		if (m_sels.GetCount() == 1)
		{
			SGFileGDB::IGDBWorkspacePtr pGdb = g_gdbList.GetGDB(m_sels[0].name, FALSE);
			if (pGdb)
			{
				CDlgCreateDataset dlg;
				dlg.m_pGdb = pGdb;
				if (dlg.DoModal() == IDOK)
				{
					
				}
			}
		}
	}
	else if (wParam == ID__NEWFEATURECLASS)
	{
		if (m_sels.GetCount() == 1)
		{
			int ltype = (m_sels[0].type % 10);
			int fi = (m_sels[0].type / 10); //g_gdbList.FindGDBindex(m_sels[0].name);
			if (fi >= 0 && (ltype==4 || ltype==5))
			{
				//if (fi >= 10000)
				//{
				//	dataset = m_sels[0].name;
				//	int ti = dataset.ReverseFind('\\');
				//	if (ti<0)
				//		ti = dataset.ReverseFind('/');
				//	if (ti > 0)
				//		dataset = dataset.Left(ti);
				//		
				//	fi -= 10000;
				//	if (fi >= 10000)
				//	{
				//		bDataset = true;
				//		fi -= 10000;
				//		ti = dataset.ReverseFind('\\');
				//		if (ti<0)
				//			ti = dataset.ReverseFind('/');
				//	}
				//	if (ti > 0)
				//	{
				//		dataset = m_sels[0].name;
				//		dataset = dataset.Mid(ti+1);
				//	}
				//}
				SGFileGDB::IGDBWorkspacePtr pGdb = g_gdbList.GetGDB(fi)->pGWS;
				if (pGdb)
				{
					CDlgNewLayer dlg;
					dlg.m_pGdb = pGdb;
					if (ltype == 4)	//import to dataset
					{
						CString buf = m_sels[0].name;
						int fi = buf.ReverseFind(L'\\');
						if (fi<0)
							fi = buf.ReverseFind(L'/');
						if (fi >= 0)
							dlg.m_dataset = buf.Mid(fi + 1);
					}

					if (dlg.DoModal() == IDOK)
					{
						Reload();
					}
				}
			}
		}
	}
	else if (wParam == ID__IMPORTFEATURECLASS)
	{
		if (m_sels.GetCount() == 1)
		{
			SGFileGDB::IGDBWorkspacePtr pGdb = g_gdbList.GetGDB(m_sels[0].name, FALSE);
			if (pGdb)
			{
				CDlgImport dlg;
				dlg.m_outputGDB = m_sels[0].name;
				if ((m_sels[0].type % 10) == 4)	//import to dataset
				{
					CString buf = m_sels[0].name;
					int fi = buf.ReverseFind(L'\\');
					if (fi<0)
						fi = buf.ReverseFind(L'/');
					if (fi>=0)
						dlg.m_dataset = buf.Mid(fi+1);
				}
				if (dlg.DoModal() == IDOK)
				{
				}
			}
		}
	}
	else if (wParam == ID__EXPORTFEATURECLASS)
	{
		if (m_sels.GetCount() > 0)
		{
			CArray<LAYInfo> allSels;
			GetAllSelectedInfo(allSels);
			if (allSels.GetCount())
			{
				CDlgExport dlg;
				dlg.m_pSels = &allSels;
				if (dlg.DoModal() == IDOK)
				{
				}
			}
		}
	}
	else if (wParam == ID__REMOVEFROMLIST)
	{
		if (MessageBox(L"Do you want to remove selected gdbs from this list?",L"Remove from list", MB_OKCANCEL) == IDOK)
		{
			int ri = 0;
			HTREEITEM hRoot = NULL;
			hRoot = m_tree.GetRootItem();
			while (hRoot)
			{
				HTREEITEM hDel = (m_tree.GetItemState(hRoot, TVIS_SELECTED) & TVIS_SELECTED) ? hRoot : NULL;
				hRoot = m_tree.GetNextSiblingItem(hRoot);
				if (hDel)
				{
					g_gdbList.RemoveGDB(NULL, m_tree.GetItemText(hDel));
					m_tree.DeleteItem(hDel);
				}
				ri++;
			}
		}
	}
	else if (wParam == ID__DELETEFROMGDB)
	{
		if (MessageBox(L"Do you want to delete selected items from GDB?\r\n(Warning:selected datasets will delete all child tables)", L"Delete from GDB", MB_OKCANCEL) == IDOK)
		{
			for (int i = 0; i < m_sels.GetCount(); i++)
			{
				m_sels[i].name;
			}
		}
	}
	return CDialog::OnCommand(wParam, lParam);
}

//https://codertw.com/%E7%A8%8B%E5%BC%8F%E8%AA%9E%E8%A8%80/532551/
//mfc q1,q2
//https://www.cctry.com/forum.php?mod=viewthread&tid=53188
//https://www.cctry.com/forum.php?mod=viewthread&tid=53189



BOOL CDlgGDBList::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_RETURN || pMsg->wParam == VK_ESCAPE)
			return TRUE;
	}
	return CDialog::PreTranslateMessage(pMsg);
}


void CDlgGDBList::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialog::OnSizing(fwSide, pRect);
	int dw = abs(pRect->right - pRect->left);
	int dh = abs(pRect->bottom - pRect->top);
	if (dw < 200)
	{
		if (fwSide == WMSZ_RIGHT || fwSide == WMSZ_TOPRIGHT || fwSide == WMSZ_BOTTOMRIGHT)
			pRect->right = pRect->left + 200;
		else
			pRect->left = pRect->right - 200;
	}
	if (dh < 200)
	{
		if (fwSide == WMSZ_BOTTOM || fwSide == WMSZ_BOTTOMLEFT || fwSide == WMSZ_BOTTOMRIGHT)
			pRect->bottom = pRect->top + 200;
		else
			pRect->top = pRect->bottom - 200;
	}
}


void CDlgGDBList::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	CWnd* pWnd = GetDlgItem(IDC_TREE);
	if (!pWnd)
		return;

	CRect rcNew;
	GetWindowRect(rcNew);
	long dX = rcNew.Width() - m_rcInit.Width();
	long dY = rcNew.Height() - m_rcInit.Height();
	GetWindowRect(m_rcInit);

	CRect rc;
	pWnd->GetWindowRect(rc);
	ScreenToClient(rc);
	rc.right += dX;
	rc.bottom += dY;
	pWnd->MoveWindow(rc);
}

void CDlgGDBList::OnBnClickedOk()
{
	Reload();
	//CDialog::OnOK();
}
