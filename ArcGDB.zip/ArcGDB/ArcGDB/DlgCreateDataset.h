#pragma once


// CDlgCreateDataset ��ܤ��

class CDlgCreateDataset : public CDialog
{
	DECLARE_DYNAMIC(CDlgCreateDataset)

public:
	CDlgCreateDataset(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgCreateDataset();
	CString m_name;
	SGSFCOMS::ISpatialReferencePtr m_pSptRef;
	SGFileGDB::IGDBWorkspacePtr m_pGdb;

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CREATEDATASET };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedSelectCoord();
	afx_msg void OnBnClickedOk();
	
};
